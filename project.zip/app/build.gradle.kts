plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
}

// AdMob IDs come from GitHub secrets; Google's official TEST ids are used when they're not set (and always in debug builds)
fun env(name: String, fallback: String): String = System.getenv(name)?.takeUnless { it.isBlank() } ?: fallback
val testAppId = "ca-app-pub-3940256099942544~3347511713"
val testBanner = "ca-app-pub-3940256099942544/9214589741"
val testRewarded = "ca-app-pub-3940256099942544/5224354917"
val testInterstitial = "ca-app-pub-3940256099942544/1033173712"

// Website with the privacy policy & terms (GitHub secret SITE_URL, e.g. https://yourname.github.io)
val siteUrl = env("SITE_URL", "https://example.com").trimEnd('/')

// Release "upload key": decoded from the UPLOAD_KEYSTORE_BASE64 secret by the GitHub workflow (never stored in the repo)
val uploadKeystore = file("upload.jks")

// Each GitHub build gets a higher version code (needed for Play Store uploads)
val buildNumber: Int = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "com.willowisp.nfcalarm"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.willowisp.nfcalarm"
        minSdk = 26
        targetSdk = 36
        versionCode = buildNumber
        versionName = "0.3.$buildNumber"
        manifestPlaceholders["admobAppId"] = env("ADMOB_APP_ID", testAppId)
        buildConfigField("String", "ADMOB_BANNER_ID", "\"${env("ADMOB_BANNER_ID", testBanner)}\"")
        buildConfigField("String", "ADMOB_REWARDED_ID", "\"${env("ADMOB_REWARDED_ID", testRewarded)}\"")
        buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"${env("ADMOB_INTERSTITIAL_ID", testInterstitial)}\"")
        buildConfigField("String", "SITE_URL", "\"$siteUrl\"")
        manifestPlaceholders["crashlyticsEnabled"] = "true"
    }

    // Fixed key: updates install over the old app, and it is the Play "upload key"
    signingConfigs {
        create("wisp") {
            storeFile = file("wisp-debug.p12")
            storePassword = "wispdebug"
            keyAlias = "wisp"
            keyPassword = "wispdebug"
            storeType = "pkcs12"
        }
        if (uploadKeystore.exists()) {
            create("upload") {
                storeFile = uploadKeystore
                storePassword = env("UPLOAD_KEY_PASSWORD", "")
                keyAlias = "upload"
                keyPassword = env("UPLOAD_KEY_PASSWORD", "")
                storeType = "pkcs12"
            }
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("wisp")
            // never show real ads in test builds (clicking your own ads can get the AdMob account banned)
            buildConfigField("String", "ADMOB_BANNER_ID", "\"$testBanner\"")
            buildConfigField("String", "ADMOB_REWARDED_ID", "\"$testRewarded\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"$testInterstitial\"")
            manifestPlaceholders["crashlyticsEnabled"] = "true"    // testing phase: send test-build crashes too
        }
        getByName("release") {
            isMinifyEnabled = false
            ndk { debugSymbolLevel = "SYMBOL_TABLE" }   // native crash symbols inside the bundle for Play
            signingConfig = if (uploadKeystore.exists()) signingConfigs.getByName("upload") else signingConfigs.getByName("wisp")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    // Firebase: Google sign-in + tag ownership database
    implementation(platform("com.google.firebase:firebase-bom:33.4.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-analytics")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    // Google Play in-app purchase (Pro unlock)
    implementation("com.android.billingclient:billing-ktx:8.0.0")

    // Google Play in-app review
    implementation("com.google.android.play:review:2.0.1")

    // AdMob + EU/UK consent (Google User Messaging Platform)
    implementation("com.google.android.gms:play-services-ads:23.3.0")
    implementation("com.google.android.ump:user-messaging-platform:3.0.0")
}
