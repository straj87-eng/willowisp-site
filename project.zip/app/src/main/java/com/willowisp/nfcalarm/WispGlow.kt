package com.willowisp.nfcalarm

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private const val OUTER = "M54,24 C57,35 71,43 71,60 C71,71.5 63.4,80 54,80 C44.6,80 37,71.5 37,61 C37,52 42,46.5 46,41.5 C46.5,48 49,52.5 53,54 C49.5,45 50,34 54,24 Z"
private const val MID = "M54.5,39 C57,47.5 64.5,52 64.5,63 C64.5,70 59.8,74.5 54,74.5 C48.2,74.5 43.5,70 43.5,64 C43.5,58.5 46.5,55 49,51.5 C49.8,56.5 52,59 55.5,59.5 C53.5,53 52.5,46 54.5,39 Z"
private const val CORE = "M54,59 C57.3,59 59.5,62.5 59.5,66 C59.5,69.3 57.1,71.5 54,71.5 C50.9,71.5 48.5,69.3 48.5,66 C48.5,62.5 50.7,59 54,59 Z"

private val GOLD = Color(0xFFFFD54F)
private val AMBER = Color(0xFFFFB300)

/**
 * The Will-O-Wisp flame on the ring screen.
 * - waiting: floats and breathes with a soft glow
 * - [flashKey] changes (correct tap): flares to a bright glow, then fades back
 * - [celebrate] = true (last tag): swirls around in golden-blue sparkles, then settles glowing
 */
@Composable
fun WispGlow(
    flashKey: Int,
    modifier: Modifier = Modifier,
    size: Dp = 210.dp,
    celebrate: Boolean = false,
    palette: WispTheme = Themes.ALL[0]
) {
    val BLUE = palette.flameOuter
    val CYAN = palette.halo
    val ICE = palette.flameCore
    val MIDC = palette.flameMid
    val outer = remember { PathParser().parsePathString(OUTER).toPath() }
    val mid = remember { PathParser().parsePathString(MID).toPath() }
    val core = remember { PathParser().parsePathString(CORE).toPath() }

    val t = rememberInfiniteTransition(label = "wisp")
    val breathe by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )
    val flicker by t.animateFloat(
        initialValue = 0.97f, targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse),
        label = "flicker"
    )
    val twinkle by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(400, easing = LinearEasing), RepeatMode.Reverse),
        label = "twinkle"
    )

    // bright flare on each correct tap
    val flare = remember { Animatable(0f) }
    LaunchedEffect(flashKey) {
        if (flashKey > 0) {
            flare.snapTo(1f)
            flare.animateTo(0f, tween(1800, easing = FastOutSlowInEasing))
        }
    }

    // final swirl: 0 → 1 over ~3.4 s, then holds at 1 (settled)
    val swirl = remember { Animatable(0f) }
    LaunchedEffect(celebrate) {
        if (celebrate) {
            swirl.snapTo(0f)
            swirl.animateTo(1f, tween(3400, easing = FastOutSlowInEasing))
        }
    }

    Canvas(modifier.size(size)) {
        val p = swirl.value
        val dim = this.size.minDimension
        val center = Offset(this.size.width / 2, this.size.height / 2)

        // path of the wisp: gentle float while waiting; spiral out and back while celebrating
        val env = if (celebrate) sin(p * PI).toFloat() else 0f          // 0 → 1 → 0
        val theta = (p * 4f * PI).toFloat()                                 // two full turns
        val orbit = dim * 0.24f * env
        val bob = if (celebrate) 0f else (breathe - 0.5f) * dim * 0.03f
        val pos = Offset(center.x + orbit * cos(theta), center.y + orbit * sin(theta) + bob)

        // brightness: tap flare, or bright during/after the celebration
        val bright = if (celebrate) maxOf(0.65f, env) else flare.value

        // soft blue halo (bright when flaring)
        val haloAlpha = (0.22f + 0.12f * breathe + 0.6f * bright).coerceAtMost(1f)
        val haloR = dim * (0.36f + 0.04f * breathe + 0.14f * bright)
        drawCircle(
            brush = Brush.radialGradient(listOf(CYAN.copy(alpha = haloAlpha), Color.Transparent), center = pos, radius = haloR),
            radius = haloR, center = pos
        )
        // golden aura when celebrating
        if (celebrate) {
            val goldR = dim * (0.30f + 0.15f * env)
            drawCircle(
                brush = Brush.radialGradient(listOf(GOLD.copy(alpha = 0.35f + 0.3f * env), Color.Transparent), center = pos, radius = goldR),
                radius = goldR, center = pos
            )
        }
        // white-hot bloom on flare
        if (bright > 0.01f) {
            val bloomR = dim * 0.22f
            drawCircle(
                brush = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.5f * bright), Color.Transparent), center = pos, radius = bloomR),
                radius = bloomR, center = pos
            )
        }

        // golden-blue sparkles swirling around the wisp, fading as it settles
        if (celebrate && p < 1f) {
            val fade = if (p < 0.8f) 1f else (1f - p) / 0.2f
            val n = 44
            for (i in 0 until n) {
                val frac = ((i * 37) % 100) / 100f
                val speed = 1.2f + (i % 5) * 0.18f
                val a = i * 2.39996f + theta * speed
                val rr = dim * (0.10f + 0.34f * frac) * (0.35f + 0.9f * env)
                val sp = Offset(pos.x + rr * cos(a), pos.y + rr * sin(a))
                val col = when (i % 3) { 0 -> GOLD; 1 -> CYAN; else -> AMBER }
                val tw = if (i % 2 == 0) twinkle else 1f - twinkle
                val alpha = (fade * (0.55f + 0.45f * tw)).coerceIn(0f, 1f)
                val dotR = dim * (0.008f + 0.010f * ((i * 13) % 7) / 6f)
                drawCircle(col.copy(alpha = alpha), radius = dotR, center = sp)
                // tiny white core for a "sparkle" look
                drawCircle(Color.White.copy(alpha = alpha * 0.8f), radius = dotR * 0.4f, center = sp)
            }
        }

        // the flame (108-unit icon geometry; its visual centre is ~ (54, 52))
        val s = dim / 80f * (1f + 0.08f * bright)
        withTransform({
            translate(left = pos.x - 54f * s, top = pos.y - 52f * s)
            scale(scaleX = s, scaleY = s, pivot = Offset.Zero)
            scale(scaleX = 1f, scaleY = flicker, pivot = Offset(54f, 80f))
        }) {
            drawPath(outer, lerp(BLUE, MIDC, 0.6f * bright))
            drawPath(mid, lerp(MIDC, ICE, 0.7f * bright))
            drawPath(core, lerp(ICE, Color.White, bright))
        }
    }
}
