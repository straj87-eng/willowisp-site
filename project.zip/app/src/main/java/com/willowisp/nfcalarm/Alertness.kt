package com.willowisp.nfcalarm

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

enum class GameType(val title: String, val emoji: String, val rules: String) {
    MEMORY("Follow the Wisp", "✨", "Watch the wisp light up the circles, then tap them in the same order. 3 rounds, each one longer."),
    MATHS("Quick Maths", "➗", "Solve 5 quick sums. Be correct, and be fast."),
    CATCH("Catch the Wisp", "🎯", "Tap the wisp the moment it appears. 8 catches — and don't tap the empty sky!")
}

/** Optional morning alertness game. One random game per day; the first attempt of the day counts. */
object Alertness {
    private fun key(cal: Calendar = Calendar.getInstance()) =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)

    fun todaysGame(): GameType {
        val values = GameType.values()
        return values[Random(key().hashCode()).nextInt(values.size)]
    }

    fun label(score: Int): String = when {
        score >= 90 -> "Wide-awake wizard 🧙"
        score >= 75 -> "Filter-coffee fresh ☕"
        score >= 55 -> "Booting up… 🔄"
        score >= 35 -> "Half-asleep zombie 🧟"
        else -> "Still dreaming 💤"
    }

    private fun all(c: Context): JSONObject =
        JSONObject(c.getSharedPreferences("wisp", Context.MODE_PRIVATE).getString("alertness", "{}") ?: "{}")

    fun today(c: Context): Int? = all(c).let { if (it.has(key())) it.getInt(key()) else null }

    /** Average of the last 7 days that have a score. */
    fun weekAverage(c: Context): Int? {
        val o = all(c)
        val cal = Calendar.getInstance()
        val scores = mutableListOf<Int>()
        repeat(7) {
            val k = key(cal)
            if (o.has(k)) scores.add(o.getInt(k))
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return if (scores.isEmpty()) null else scores.average().toInt()
    }

    /** Saves the score if it's today's first game. Returns true if it was saved. */
    fun record(c: Context, score: Int): Boolean {
        val o = all(c)
        if (o.has(key())) return false
        o.put(key(), score)
        c.getSharedPreferences("wisp", Context.MODE_PRIVATE).edit().putString("alertness", o.toString()).apply()
        return true
    }
}
