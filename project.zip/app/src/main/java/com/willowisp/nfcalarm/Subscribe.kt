package com.willowisp.nfcalarm

import android.content.Context
import android.telephony.TelephonyManager
import java.util.Locale

/** Small helpers shared by the account and affiliate code. */
object Subscribe {
    fun country(c: Context): String {
        val tm = c.getSystemService(TelephonyManager::class.java)
        val iso = listOf(tm?.simCountryIso, tm?.networkCountryIso, Locale.getDefault().country)
            .firstOrNull { !it.isNullOrBlank() } ?: "US"
        return iso.uppercase(Locale.US)
    }
}
