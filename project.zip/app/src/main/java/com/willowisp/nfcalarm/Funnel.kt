package com.willowisp.nfcalarm

import android.content.Context

/**
 * Activation funnel for Firebase / Google Analytics:
 * first_open (automatic) → alarm_created → tag_registered → first_alarm_started →
 * first_wisp_completed → day_3_return → day_7_return → pro_view → pro_purchase.
 * "First" events fire once per install.
 */
object Funnel {
    fun once(c: Context, event: String, vararg params: Pair<String, Any?>) {
        val key = "fn_$event"
        if (Store.getStr(c, key) == "1") return
        Store.putStr(c, key, "1")
        Analytics.log(c, event, *params)
    }

    /** Day-3 and day-7 return, counted when the app is opened or the alarm rings on/after that day. */
    fun checkReturn(c: Context) {
        val installed = try {
            c.packageManager.getPackageInfo(c.packageName, 0).firstInstallTime
        } catch (_: Exception) { return }
        val days = ((System.currentTimeMillis() - installed) / (24L * 60 * 60 * 1000)).toInt()
        if (days >= 3) once(c, "day_3_return", "days_since_install" to days)
        if (days >= 7) once(c, "day_7_return", "days_since_install" to days)
    }
}
