package com.willowisp.nfcalarm

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthRecentLoginRequiredException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

/**
 * Required Google sign-in. Creates users/{uid} in Firestore with name, email and country.
 * Marketing emails are a separate, optional consent (stored as marketingConsent).
 */
object Account {
    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()

    fun isLoggedIn(): Boolean = auth.currentUser?.let { !it.isAnonymous } ?: false
    fun email(): String? = auth.currentUser?.email

    /** Name shown in "Hi …": the user's own nickname if set, else their Google first name. */
    fun nickname(c: Context): String =
        Store.getStr(c, "nickname").ifBlank { Store.getStr(c, "firstName") }.ifBlank { "there" }

    private suspend fun googleCredential(activity: Activity): GoogleIdTokenCredential {
        val option = GetSignInWithGoogleOption.Builder(activity.getString(R.string.default_web_client_id)).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val cred = CredentialManager.create(activity).getCredential(activity, request).credential
        if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            return GoogleIdTokenCredential.createFrom(cred.data)
        }
        throw IllegalStateException("No Google account selected")
    }

    suspend fun signIn(activity: Activity, marketing: Boolean) {
        val g = googleCredential(activity)
        if (auth.currentUser?.isAnonymous == true) auth.signOut()
        auth.signInWithCredential(GoogleAuthProvider.getCredential(g.idToken, null)).await()
        val first = (g.givenName ?: g.displayName?.substringBefore(" ") ?: "").trim()
        Store.putStr(activity, "firstName", first)
        Store.putStr(activity, "marketing", marketing.toString())
        val uid = auth.currentUser?.uid ?: throw IllegalStateException("Sign-in failed")
        db.collection("users").document(uid).set(
            mapOf(
                "name" to (g.displayName ?: ""),
                "firstName" to first,
                "email" to g.id,
                "country" to Subscribe.country(activity),
                "marketingConsent" to marketing,
                "platform" to "android",
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()
    }

    suspend fun setMarketing(c: Context, on: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users").document(uid).set(
            mapOf("marketingConsent" to on, "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()
        ).await()
        Store.putStr(c, "marketing", on.toString())
    }

    suspend fun signOut(activity: Activity) {
        auth.signOut()
        try { CredentialManager.create(activity).clearCredentialState(ClearCredentialStateRequest()) } catch (_: Exception) { }
    }

    /** Deletes the account and its data from our servers (Play Store requirement). */
    suspend fun deleteAccount(activity: Activity) {
        val user = auth.currentUser ?: return
        db.collection("users").document(user.uid).delete().await()
        try {
            user.delete().await()
        } catch (e: FirebaseAuthRecentLoginRequiredException) {
            val g = googleCredential(activity)          // re-confirm with Google, then delete
            user.reauthenticate(GoogleAuthProvider.getCredential(g.idToken, null)).await()
            user.delete().await()
        }
        listOf("firstName", "nickname", "marketing").forEach { Store.putStr(activity, it, "") }
        signOut(activity)
    }
}
