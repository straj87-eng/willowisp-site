package com.willowisp.nfcalarm

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView

/**
 * Sets Compose content through a plain ComposeView.
 * Avoids a crash seen on some phones where androidx's setContent{} finds no content view
 * (NullPointerException in ViewGroup.getChildAt inside ComponentActivity.setContent).
 */
fun ComponentActivity.setComposeContent(barColor: Color = Color(0xFF0B1430), content: @Composable () -> Unit) {
    // targetSdk 36 always draws edge-to-edge: pad the app inside the system bars, fill the bars with a dark colour
    setContentView(ComposeView(this).apply {
        setContent {
            Box(Modifier.fillMaxSize().background(barColor).safeDrawingPadding()) { content() }
        }
    })
}

fun isOnline(c: Context): Boolean {
    return try {
        val cm = c.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) { false }
}
