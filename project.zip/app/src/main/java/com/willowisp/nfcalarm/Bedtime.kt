package com.willowisp.nfcalarm

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.graphics.drawable.Icon
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** Daily reminder 1 or 2 hours before the user's bedtime. */
object Bedtime {

    private fun operation(c: Context): PendingIntent = PendingIntent.getBroadcast(
        c, 9001, Intent(c, BedtimeReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun nextReminder(c: Context, now: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, Store.bedHour(c))
            set(Calendar.MINUTE, Store.bedMinute(c))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.MINUTE, -Store.bedLeadMin(c))
        }
        while (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(operation(c))
        if (!Store.bedOn(c)) return
        val t = nextReminder(c)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, operation(c))
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, operation(c))
        }
    }

    /** Hours and minutes of sleep between bedtime and the alarm. */
    fun sleepText(c: Context, alarm: AlarmItem?): String {
        val wake = (alarm?.hour ?: 6) * 60 + (alarm?.minute ?: 0)
        val bed = Store.bedHour(c) * 60 + Store.bedMinute(c)
        val mins = ((wake - bed) + 24 * 60) % (24 * 60)
        return if (mins % 60 == 0) "${mins / 60} h" else "${mins / 60} h ${mins % 60} min"
    }

    const val ACTION_ENABLE = "com.willowisp.nfcalarm.ENABLE_ALARM"
    private const val NOTIF_ID = 77

    private fun channel(c: Context): String {
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = "wisp_bedtime"
        if (nm.getNotificationChannel(ch) == null) {
            nm.createNotificationChannel(NotificationChannel(ch, "Bedtime reminder", NotificationManager.IMPORTANCE_DEFAULT))
        }
        return ch
    }

    /** "Turn on alarm" button in the bedtime notification. */
    fun enableFromNotification(c: Context) {
        val alarm = Store.alarms(c).firstOrNull() ?: return
        val on = alarm.copy(enabled = true)
        Store.upsertAlarm(c, on)
        AlarmScheduler.schedule(c, on)
        val wake = "%02d:%02d".format(on.hour, on.minute)
        val n = Notification.Builder(c, channel(c))
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ Alarm set for $wake")
            .setContentText(AlarmScheduler.untilText(AlarmScheduler.nextTrigger(on)) + " · Sleep well 🌙")
            .setAutoCancel(true)
            .build()
        try { c.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n) } catch (_: SecurityException) { }
    }

    fun notifyNow(c: Context) {
        val alarm = Store.alarms(c).firstOrNull() ?: return

        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = channel(c)
        val lead = Store.bedLeadMin(c) / 60
        val bed = "%02d:%02d".format(Store.bedHour(c), Store.bedMinute(c))
        val wake = "%02d:%02d".format(alarm.hour, alarm.minute)
        val where = if (alarm.noTags) "" else " Your ${alarm.tagSet} tags will be waiting."
        val why = Goals.current(c)?.let { " ${it.emoji} ${it.bedtimeLine}" } ?: ""
        val body = (if (alarm.enabled) {
            "Lights out at $bed for ${sleepText(c, alarm)} of sleep before your $wake alarm.$where " +
                "Travelling? Switch the alarm to your Travel tags or turn it off."
        } else {
            "Your alarm is OFF. Switch it on for $wake — that's ${sleepText(c, alarm)} of sleep if lights are out at $bed." +
                (if (alarm.noTags) "" else " It will use your ${alarm.tagSet} tags.")
        }) + why
        val open = PendingIntent.getActivity(c, 4, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val builder = Notification.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🌙 Bedtime in $lead hour" + if (lead > 1) "s" else "")
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(open)
            .setAutoCancel(true)
        if (!alarm.enabled) {
            val enable = PendingIntent.getBroadcast(
                c, 9002, Intent(c, BedtimeReceiver::class.java).setAction(ACTION_ENABLE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(c, android.R.drawable.ic_lock_idle_alarm), "Turn on $wake alarm", enable
                ).build()
            )
        }
        try { nm.notify(NOTIF_ID, builder.build()) } catch (_: SecurityException) { }
    }
}

class BedtimeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action == Bedtime.ACTION_ENABLE) {
            Bedtime.enableFromNotification(c)
            return
        }
        Bedtime.notifyNow(c)
        Bedtime.schedule(c)   // book tomorrow's reminder
    }
}
