package com.willowisp.nfcalarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.app.Notification
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class Badge(val days: Int, val emoji: String, val title: String, val caption: String)

/** Habit tracking: one "win" per day when every tag was tapped (full cycle). */
object Habit {

    /**
     * Badge schedule:
     *  - day 0 (install), then every day for days 1–21
     *  - every 5 days from 25 to 90
     *  - every 20 days after 90 (110, 130 … 370), then "Eternal Wisp" every 20 days forever
     */
    val BADGES = listOf(
        Badge(0, "🌱", "Wisp Awakened", "You installed Will-O-Wisp. Your bed is already nervous."),
        // ---- daily: days 1–21 ----
        Badge(1, "🕯️", "First Flicker", "You got up. Historians will write about this."),
        Badge(2, "🎲", "Not a Fluke", "Two mornings in a row. Officially not an accident."),
        Badge(3, "😤", "Snooze Rebel", "Three days without negotiating with a pillow."),
        Badge(4, "🐓", "Rooster's Rival", "The rooster is checking YOUR schedule now."),
        Badge(5, "🖐️", "High Five", "Five mornings. Your alarm deserves a raise."),
        Badge(6, "☕", "Chai Before Sunrise", "Up before the kettle even whistles."),
        Badge(7, "⚔️", "Week Warrior", "Seven mornings. Your bed has filed a complaint."),
        Badge(8, "💔", "Bed Breakup", "You and your bed are 'just friends' now."),
        Badge(9, "🧭", "Tag Explorer", "You can find every tag in the dark."),
        Badge(10, "🔟", "Perfect Ten", "Double digits! The snooze button felt that."),
        Badge(11, "🏏", "Opening Batsman", "First one at the crease every single morning."),
        Badge(12, "🌅", "Dawn Patrol", "Reporting for sunrise duty, sir!"),
        Badge(13, "🍀", "Lucky Thirteen", "Superstition says unlucky. Your streak disagrees."),
        Badge(14, "🔥", "Fortnight Phoenix", "Rising from the duvet like it owes you money."),
        Badge(15, "🛺", "First Auto Out", "Faster than the first auto-rickshaw of the day."),
        Badge(16, "🧘", "Morning Monk", "Calm, awake and suspiciously productive."),
        Badge(17, "🦸", "Duvet Defeater", "The blanket put up a fight. It lost."),
        Badge(18, "📯", "Human Alarm", "You don't need an alarm. You ARE the alarm."),
        Badge(19, "🚂", "Morning Express", "Running on time — unlike most trains."),
        Badge(20, "🎯", "Twenty Bullseye", "Twenty out of twenty. Bullseye."),
        Badge(21, "🐣", "Habit Hatchling", "21 days — science says habit. Your blanket says betrayal."),
        // ---- every 5 days: 25–90 ----
        Badge(25, "🥈", "Silver Sunrise", "Twenty-five mornings. Silver jubilee vibes."),
        Badge(30, "😈", "Morning Menace", "A full month. Roosters are taking notes."),
        Badge(35, "🌄", "Hilltop Riser", "You see sunrises other people only see on wallpapers."),
        Badge(40, "🧱", "Iron Routine", "Forty days. This habit has a foundation now."),
        Badge(45, "🦅", "Early Eagle", "Early birds look up to you."),
        Badge(50, "🏏", "Half-Century Hustler", "50 not out! The pillow has been clean bowled."),
        Badge(55, "⚡", "Power Starter", "Booting up faster than your phone."),
        Badge(60, "🗓️", "Two-Month Titan", "Two months. Calendars respect you."),
        Badge(65, "🛡️", "Snooze-Proof", "Certified 100% snooze-resistant."),
        Badge(70, "🌞", "Sun Summoner", "Pretty sure the sun waits for your alarm now."),
        Badge(75, "🦉", "Owl Evictor", "Night owls are moving out of your neighbourhood."),
        Badge(80, "🎖️", "Dawn Commander", "Leading the morning army. Rank: legendary."),
        Badge(85, "🏔️", "Summit Riser", "Almost at the top of the mountain."),
        Badge(90, "👑", "Quarter-Year King", "90 days. You don't wake up — you reign."),
        // ---- every 20 days after 90 ----
        Badge(110, "🚀", "Bedtime Escapologist", "110 escapes from bed. Houdini wants tips."),
        Badge(130, "🧪", "Morning Scientist", "Experiment complete: humans CAN wake up."),
        Badge(150, "🏆", "Sunrise Sultan", "150 mornings conquered. Coffee bows before you."),
        Badge(170, "🌊", "Unstoppable Tide", "Comes in every morning, right on time."),
        Badge(190, "🐉", "Dragon of Dawn", "Breathing fire on the snooze button."),
        Badge(210, "🌟", "Seven-Month Star", "Shining before the sun does."),
        Badge(230, "🛰️", "Orbit Keeper", "Circling your routine with satellite precision."),
        Badge(250, "💎", "Diamond Dawn", "250 mornings. Pressure made a diamond."),
        Badge(270, "🧗", "Cliff-Hanger Champ", "Never once left the streak hanging."),
        Badge(290, "🌋", "Morning Volcano", "Erupting out of bed, daily."),
        Badge(310, "🎻", "Sunrise Symphony", "Every morning, the same perfect note."),
        Badge(330, "🪐", "Planetary Riser", "Even Saturn's rings are impressed."),
        Badge(350, "🔱", "Almost Immortal", "Twenty more mornings to legend status."),
        Badge(370, "🧙", "Will-O-Wisp Legend", "A whole year and more. Snooze buttons fear your name.")
    )

    private const val LAST_NAMED = 370

    /** Badge earned exactly on day [d], including the endless "Eternal Wisp" ones after day 370. */
    fun badgeAt(d: Int): Badge? {
        BADGES.firstOrNull { it.days == d }?.let { return it }
        if (d > LAST_NAMED && (d - LAST_NAMED) % 20 == 0) {
            val n = (d - LAST_NAMED) / 20
            return Badge(d, "✨", "Eternal Wisp ×$n", "Still going. Legends don't retire.")
        }
        return null
    }

    private val fmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun key(cal: Calendar): String = fmt.format(cal.time)

    fun total(c: Context): Int = Store.history(c).size

    // ---------- streak freezes (Pro: 2 per calendar month) ----------
    const val FREEZES_PER_MONTH = 2

    private fun monthOf(k: String) = k.substring(0, 7)   // "yyyy-MM"

    fun freezesLeft(c: Context, cal: Calendar = Calendar.getInstance()): Int {
        if (!Store.isPro(c)) return 0
        val m = monthOf(key(cal))
        val used = Store.frozen(c).count { monthOf(it) == m }
        return (FREEZES_PER_MONTH - used).coerceAtLeast(0)
    }

    /**
     * Automatically covers missed days (up to yesterday) with freezes, so an active streak survives.
     * Only applies when the day before the gap was a wake-up or an earlier freeze.
     */
    fun applyFreezes(c: Context) {
        if (!Store.isPro(c)) return
        val h = Store.history(c)
        if (h.isEmpty()) return
        val frozen = Store.frozen(c).toMutableSet()
        // find the most recent active day before today
        val cal = Calendar.getInstance()
        val todayKey = key(cal)
        cal.add(Calendar.DAY_OF_YEAR, -1)
        var gap = 0
        while (gap < 62 && key(cal) !in h && key(cal) !in frozen) {
            cal.add(Calendar.DAY_OF_YEAR, -1); gap++
        }
        if (gap == 0 || gap >= 62) return   // no gap, or no recent activity
        // the missed days, from the day after the last active day up to yesterday
        cal.add(Calendar.DAY_OF_YEAR, 1)
        val missed = mutableListOf<String>()
        while (key(cal) != todayKey) {
            missed.add(key(cal)); cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        // only freeze if the WHOLE gap can be covered — never waste freezes on a streak that breaks anyway
        val pen = Store.penalties(c)
        if (missed.any { it in pen }) return   // a switched-off alarm can't be covered by a freeze
        val trial = frozen.toMutableSet()
        for (k in missed) {
            if (trial.count { monthOf(it) == monthOf(k) } >= FREEZES_PER_MONTH) return
            trial.add(k)
        }
        Store.saveFrozen(c, trial)
    }

    /** Consecutive wake-ups; frozen days bridge gaps but don't add to the count. */
    fun streak(c: Context): Int {
        val h = Store.history(c)
        val f = Store.frozen(c)
        val pen = Store.penalties(c)
        val cal = Calendar.getInstance()
        if (key(cal) in pen && key(cal) !in h) return 0   // switched off during today's alarm
        if (key(cal) !in h) cal.add(Calendar.DAY_OF_YEAR, -1)   // today not done yet: count up to yesterday
        var n = 0
        while (key(cal) in h || key(cal) in f) {
            if (key(cal) in h) n++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return n
    }

    fun latestBadge(c: Context): Badge? {
        val t = total(c)
        if (t <= LAST_NAMED) return BADGES.lastOrNull { it.days <= t }
        return badgeAt(LAST_NAMED + ((t - LAST_NAMED) / 20) * 20)
    }

    fun nextBadge(c: Context): Badge? {
        val t = total(c)
        BADGES.firstOrNull { it.days > t }?.let { return it }
        return badgeAt(LAST_NAMED + ((t - LAST_NAMED) / 20 + 1) * 20)
    }

    /**
     * 8 weeks x 7 days. grid[week][dayOfWeek]: 1 = done, 2 = frozen, 0 = missed, -1 = future.
     * Last column is the current week; rows run Sunday..Saturday.
     */
    fun grid(c: Context): List<List<Int>> {
        val h = Store.history(c)
        val f = Store.frozen(c)
        val today = Calendar.getInstance()
        val todayKey = key(today)
        val start = (today.clone() as Calendar).apply {
            set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY)
            add(Calendar.WEEK_OF_YEAR, -7)
        }
        var future = false
        return (0 until 8).map {
            (0 until 7).map {
                val k = key(start)
                val v = when {
                    future -> -1
                    k in h -> 1
                    k in f -> 2
                    else -> 0
                }
                if (k == todayKey) future = true
                start.add(Calendar.DAY_OF_YEAR, 1)
                v
            }
        }
    }

    /** Phone was switched off while the alarm rang: streak broken for that day, with a cheeky notification. */
    fun applyEscapePenalty(c: Context, ringingSince: Long) {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date(ringingSince))
        Store.addPenalty(c, day)
        Analytics.log(c, "alarm_escaped_power_off")
        Store.putStr(c, "penaltyNotice", "🙈 The wisp saw you switch off your phone during the alarm. Streak reset — get it back tomorrow!")
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = "wisp_badges"
        if (nm.getNotificationChannel(ch) == null) {
            nm.createNotificationChannel(NotificationChannel(ch, "Badges", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(c, 5, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🙈 The wisp saw that")
            .setContentText("Switching off the phone during the alarm broke your streak. Start a new one tomorrow!")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { nm.notify(90, n) } catch (_: SecurityException) { }
        HabitWidget.updateAll(c)
    }

    /** Clean start: clears wake-up history, streak freezes and alertness scores. */
    fun reset(c: Context) {
        Store.saveHistory(c, emptySet())
        Store.saveFrozen(c, emptySet())
        c.getSharedPreferences("wisp", Context.MODE_PRIVATE).edit().remove("penalties").commit()
        c.getSharedPreferences("wisp", Context.MODE_PRIVATE).edit().remove("alertness").commit()
        HabitWidget.updateAll(c)
    }

    /** Called when the full tag cycle is completed. Returns a newly earned badge, if any. */
    fun recordWin(c: Context): Badge? {
        applyFreezes(c)   // protect the streak before adding today
        val h = Store.history(c).toMutableSet()
        if (!h.add(key(Calendar.getInstance()))) return null   // already counted today
        Store.saveHistory(c, h)
        val badge = badgeAt(h.size)
        if (badge != null) notifyBadge(c, badge)
        HabitWidget.updateAll(c)
        return badge
    }

    private fun notifyBadge(c: Context, b: Badge) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = "wisp_badges"
        if (nm.getNotificationChannel(ch) == null) {
            nm.createNotificationChannel(NotificationChannel(ch, "Badges", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(
            c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, ch)
            .setSmallIcon(android.R.drawable.star_on)
            .setContentTitle("${b.emoji} You're now a ${b.title}!")
            .setContentText(b.caption)
            .setStyle(Notification.BigTextStyle().bigText("${b.caption}\n${b.days} full wake-ups completed."))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { nm.notify(100 + b.days, n) } catch (_: SecurityException) { }
    }
}
