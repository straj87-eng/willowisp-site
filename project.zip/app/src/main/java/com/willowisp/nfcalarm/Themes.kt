package com.willowisp.nfcalarm

import android.content.Context
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/** App + wisp colour theme. Midnight Wisp is free; the rest are Pro. */
data class WispTheme(
    val id: String,
    val name: String,
    val emoji: String,
    val pro: Boolean,
    val dark: Boolean,
    val primary: Color,
    val secondary: Color,
    val background: Color,
    val surface: Color,
    val flameOuter: Color,
    val flameMid: Color,
    val flameCore: Color,
    val halo: Color
)

object Themes {
    val ALL = listOf(
        WispTheme("midnight", "Midnight Wisp", "🌙", false, true,
            Color(0xFF8AB4FF), Color(0xFF56CCF2), Color(0xFF0E1630), Color(0xFF17213F),
            Color(0xFF2F80ED), Color(0xFF56CCF2), Color(0xFFE6FBFF), Color(0xFF56CCF2)),
        WispTheme("ember", "Ember", "🔥", true, true,
            Color(0xFFFFB37A), Color(0xFFFF7A45), Color(0xFF1E1008), Color(0xFF2E1A10),
            Color(0xFFE8590C), Color(0xFFFFA94D), Color(0xFFFFF4E0), Color(0xFFFF8A3D)),
        WispTheme("aurora", "Aurora", "🌌", true, true,
            Color(0xFF7CF5C8), Color(0xFF4DD0E1), Color(0xFF071A1A), Color(0xFF0F2A2A),
            Color(0xFF00A884), Color(0xFF5CF2C2), Color(0xFFE9FFF8), Color(0xFF3DE0B0)),
        WispTheme("royal", "Royal", "👑", true, true,
            Color(0xFFFFD54F), Color(0xFFFF6F9C), Color(0xFF22050E), Color(0xFF3A0C1C),
            Color(0xFFC2185B), Color(0xFFFF80AB), Color(0xFFFFF0F5), Color(0xFFFF4F9A)),
        WispTheme("dawn", "Dawn", "🌅", true, false,
            Color(0xFFD9480F), Color(0xFFE64980), Color(0xFFFFF4EC), Color(0xFFFFFFFF),
            Color(0xFFFF6B6B), Color(0xFFFFA94D), Color(0xFFFFF9DB), Color(0xFFFF922B))
    )

    fun byId(id: String): WispTheme = ALL.firstOrNull { it.id == id } ?: ALL[0]

    /** The saved theme, falling back to the free one if Pro isn't active. */
    fun current(c: Context): WispTheme {
        val t = byId(Store.getStr(c, "theme"))
        return if (t.pro && !Store.isPro(c)) ALL[0] else t
    }

    fun scheme(t: WispTheme): ColorScheme =
        if (t.dark) darkColorScheme(
            primary = t.primary,
            secondary = t.secondary,
            tertiary = t.secondary,
            background = t.background,
            surface = t.background,
            surfaceVariant = t.surface,
            primaryContainer = t.surface,
            secondaryContainer = t.surface
        ) else lightColorScheme(
            primary = t.primary,
            secondary = t.secondary,
            tertiary = t.secondary,
            background = t.background,
            surface = t.background,
            primaryContainer = Color(0xFFFFE3D3),
            secondaryContainer = Color(0xFFFFE3D3)
        )
}
