package com.willowisp.nfcalarm

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * AdMob for free users only: a banner on the main screen and an optional rewarded ad for "Pro tonight".
 * Never shown on the ring, sunrise, wake-up or game screens.
 * The EU/UK consent form (Google UMP) is shown first when required.
 */
object Ads {
    var ready by mutableStateOf(false)
        private set
    var rewardedReady by mutableStateOf(false)
        private set

    private var started = false
    private var rewarded: RewardedAd? = null

    fun init(activity: Activity) {
        val ci = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()
        ci.requestConsentInfoUpdate(activity, params, {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ -> start(activity, ci) }
        }, { _ -> start(activity, ci) })
        if (ci.canRequestAds()) start(activity, ci)   // consent already given in an earlier session
    }

    private fun start(activity: Activity, ci: ConsentInformation) {
        if (started || !ci.canRequestAds()) return
        started = true
        MobileAds.initialize(activity) {
            activity.runOnUiThread {
                ready = true
                loadRewarded(activity)
            }
        }
    }

    fun loadRewarded(c: Context) {
        RewardedAd.load(c, BuildConfig.ADMOB_REWARDED_ID, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                rewarded = ad
                rewardedReady = true
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                rewarded = null
                rewardedReady = false
            }
        })
    }

    fun showRewarded(activity: Activity, onReward: () -> Unit) {
        val ad = rewarded ?: return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewarded = null
                rewardedReady = false
                loadRewarded(activity)
            }
        }
        ad.show(activity) { _ -> onReward() }
    }

    // ---------- interstitial: after a game started from the main screen, max once a day, free users only ----------
    private var interstitial: InterstitialAd? = null

    private fun today(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())

    fun interstitialAllowed(c: Context): Boolean =
        ready && !Store.isPro(c) && Store.getStr(c, "interDay") != today()

    fun loadInterstitial(c: Context) {
        if (!interstitialAllowed(c)) return
        InterstitialAd.load(c, BuildConfig.ADMOB_INTERSTITIAL_ID, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
            })
    }

    /** Shows the interstitial if one is ready; always calls [onDone] afterwards. */
    fun showInterstitial(activity: Activity, onDone: () -> Unit) {
        val ad = interstitial
        if (ad == null || !interstitialAllowed(activity)) { onDone(); return }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { interstitial = null; onDone() }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { interstitial = null; onDone() }
        }
        Store.putStr(activity, "interDay", today())
        ad.show(activity)
    }

    fun privacyOptionsRequired(c: Context): Boolean =
        UserMessagingPlatform.getConsentInformation(c).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> }
    }
}

@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    val widthDp = LocalConfiguration.current.screenWidthDp
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { c ->
            AdView(c).apply {
                setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(c, widthDp))
                adUnitId = BuildConfig.ADMOB_BANNER_ID
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
