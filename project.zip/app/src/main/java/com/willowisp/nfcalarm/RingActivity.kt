package com.willowisp.nfcalarm

import android.app.KeyguardManager
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RingActivity : ComponentActivity(), NfcAdapter.ReaderCallback {
    private var nfc: NfcAdapter? = null
    private var appTheme: WispTheme = Themes.ALL[0]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        nfc = NfcAdapter.getDefaultAdapter(this)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* back is disabled while ringing */ }
        })
        appTheme = Themes.current(this)
        setComposeContent { MaterialTheme(colorScheme = Themes.scheme(appTheme)) { RingScreen() } }
    }

    override fun onResume() {
        super.onResume()
        nfc?.enableReaderMode(
            this, this,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            null
        )
    }

    override fun onPause() {
        super.onPause()
        nfc?.disableReaderMode(this)
    }

    override fun onTagDiscovered(tag: Tag) {
        val uid = uidHex(tag.id)
        runOnUiThread { AlarmService.onTag(uid) }
    }

    @Composable
    private fun RingScreen() {
        val s by AlarmService.state.collectAsState()
        var seenActive by remember { mutableStateOf(false) }
        var celebrating by remember { mutableStateOf(false) }
        var now by remember { mutableStateOf(System.currentTimeMillis()) }

        LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
        LaunchedEffect(s.active) {
            if (s.active) {
                seenActive = true
            } else if (seenActive) {
                if (s.won) {           // last tag tapped: let the wisp swirl and settle
                    celebrating = true
                    delay(8000)
                }
                finish()
            }
        }
        LaunchedEffect(Unit) {
            delay(4000)
            if (!AlarmService.state.value.active && !seenActive) finish()
        }

        val km = getSystemService(KeyguardManager::class.java)
        val locked = now > 0 && km.isKeyguardLocked

        if (celebrating) {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
                ) {
                    WispGlow(flashKey = 0, size = 300.dp, celebrate = true, palette = appTheme)
                    Text(if (s.test) "Test complete ✓" else "Good morning! ☀️", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    if (!s.test) {
                        Goals.current(this@RingActivity)?.let { g ->
                            Text(g.winLine, fontSize = 18.sp, textAlign = TextAlign.Center)
                        }
                    }
                    Text(
                        if (s.test) "Test runs don't count toward your streak"
                        else "🔥 ${Habit.streak(this@RingActivity)}-day streak",
                        fontSize = 20.sp, color = MaterialTheme.colorScheme.primary
                    )
                    if (!s.test && Alertness.today(this@RingActivity) == null) {
                        Button(onClick = {
                            startActivity(Intent(this@RingActivity, GameActivity::class.java))
                            finish()
                        }) { Text("🧠 Test my alertness") }
                    }
                }
            }
            return
        }

        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
            ) {
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)), fontSize = 60.sp, fontWeight = FontWeight.Bold)
                Text((if (s.crazy) "CRAZY MODE" else "NORMAL MODE") + (if (s.test) " · TEST" else ""), color = MaterialTheme.colorScheme.primary)
                WispGlow(flashKey = s.index, palette = appTheme)

                if (s.sequence.isEmpty()) {
                    Text(if (s.noTags) "Rise and shine!" else "No tags to tap", fontSize = 22.sp)
                    Button(onClick = { AlarmService.stopNoTags() }) { Text("Stop alarm") }
                } else if (s.index < s.sequence.size) {
                    Text("Tap tag ${s.index + 1} of ${s.sequence.size}", fontSize = 20.sp)
                    Text(
                        s.sequence[s.index].name, fontSize = 44.sp, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.primary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        s.sequence.indices.forEach { i ->
                            Box(
                                Modifier.size(14.dp).clip(CircleShape).background(
                                    if (i < s.index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                )
                            )
                        }
                    }
                    s.secondsLeft?.let {
                        Text("Silenced — reach it within $it s", fontSize = 20.sp, color = MaterialTheme.colorScheme.tertiary)
                    }
                }
                if (s.message.isNotEmpty()) Text(s.message, textAlign = TextAlign.Center)
                Goals.current(this@RingActivity)?.let { g ->
                    Text("${g.emoji} ${g.ringLine}", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary)
                }
                if (locked) {
                    Button(onClick = { km.requestDismissKeyguard(this@RingActivity, null) }) { Text("Unlock phone to scan tags") }
                }
                if (nfc?.isEnabled == false) {
                    Button(onClick = { startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }) { Text("Turn on NFC") }
                }
            }
        }
    }
}
