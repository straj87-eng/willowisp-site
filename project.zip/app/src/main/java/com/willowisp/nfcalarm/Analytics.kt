package com.willowisp.nfcalarm

import android.content.Context
import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics

/**
 * Anonymous usage stats (Firebase / Google Analytics): daily users and retention come automatically;
 * these events add how people actually use the alarm. No names, emails or tag IDs are sent.
 */
object Analytics {
    private fun fa(c: Context) = FirebaseAnalytics.getInstance(c)

    fun log(c: Context, event: String, vararg params: Pair<String, Any?>) {
        try {
            val b = Bundle()
            params.forEach { (k, v) ->
                when (v) {
                    is Int -> b.putLong(k, v.toLong())
                    is Long -> b.putLong(k, v)
                    is Double -> b.putDouble(k, v)
                    is Boolean -> b.putString(k, v.toString())
                    null -> { }
                    else -> b.putString(k, v.toString().take(90))
                }
            }
            b.putString("build", if (BuildConfig.DEBUG) "debug" else "release")
            fa(c).logEvent(event, b)
        } catch (_: Exception) { }
    }

    /** Snapshot of the user's setup, refreshed whenever the app opens. */
    fun updateUserProperties(c: Context) {
        try {
            val tags = Store.tags(c)
            fa(c).setUserProperty("tag_count", tags.count { it.enabled }.toString())
            fa(c).setUserProperty("tag_sets", tags.map { it.set }.distinct().size.toString())
            fa(c).setUserProperty("is_pro", Store.isPro(c).toString())
            val s = Habit.streak(c)
            fa(c).setUserProperty("streak", when { s == 0 -> "0"; s < 7 -> "1-6"; s < 21 -> "7-20"; s < 90 -> "21-89"; else -> "90+" })
            fa(c).setUserProperty("wakeups_total", Habit.total(c).let { if (it >= 100) "100+" else it.toString() })
        } catch (_: Exception) { }
    }
}
