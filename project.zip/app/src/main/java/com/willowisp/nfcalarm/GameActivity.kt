package com.willowisp.nfcalarm

import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/** Optional morning alertness game: a random mini-game each day, scored 0–100 %. */
class GameActivity : ComponentActivity() {
    private val appTheme by lazy { Themes.current(this) }
    private val fromMain by lazy { intent.getBooleanExtra("fromMain", false) }

    /** Ads only when opened from the main screen (never right after the alarm) and never over the lock screen. */
    private fun adsAllowedHere(): Boolean =
        fromMain && !getSystemService(android.app.KeyguardManager::class.java).isKeyguardLocked

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (adsAllowedHere()) Ads.loadInterstitial(this)
        setComposeContent {
            MaterialTheme(colorScheme = Themes.scheme(appTheme)) {
                Surface(Modifier.fillMaxSize()) { GameRoot() }
            }
        }
    }

    @Composable
    private fun GameRoot() {
        val game = remember { Alertness.todaysGame() }
        var phase by remember { mutableIntStateOf(0) }      // 0 intro, 1 playing, 2 result
        var score by remember { mutableIntStateOf(0) }
        var counted by remember { mutableStateOf(false) }
        val onDone: (Int) -> Unit = { s ->
            score = s.coerceIn(0, 100)
            counted = Alertness.record(this@GameActivity, score)
            Analytics.log(this@GameActivity, "game_played", "game" to game.name, "score" to score, "from_main" to fromMain)
            phase = 2
        }
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (phase) {
                0 -> Intro(game) { phase = 1 }
                1 -> when (game) {
                    GameType.MEMORY -> MemoryGame(onDone)
                    GameType.MATHS -> MathsGame(onDone)
                    GameType.CATCH -> CatchGame(onDone)
                }
                else -> Result(score, counted)
            }
        }
    }

    @Composable
    private fun Intro(game: GameType, onStart: () -> Unit) {
        Box(Modifier.height(60.dp))
        Text("🧠 Morning alertness check", fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
        Text("${game.emoji} ${game.title}", fontSize = 32.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(game.rules, textAlign = TextAlign.Center)
        val today = Alertness.today(this@GameActivity)
        Text(
            if (today == null) "Your first try today counts as today's score."
            else "Today's score is already $today %. This one is just practice.",
            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center
        )
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Start") }
        OutlinedButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) { Text("Not now") }
    }

    @Composable
    private fun Result(score: Int, counted: Boolean) {
        Box(Modifier.height(60.dp))
        WispGlow(flashKey = 1, size = 160.dp, celebrate = score >= 75, palette = appTheme)
        Text("$score %", fontSize = 64.sp, fontWeight = FontWeight.Bold)
        Text("alert", fontSize = 18.sp)
        Text(Alertness.label(score), fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Text(
            if (counted) "Saved as today's alertness score."
            else "Practice round — today's first score is kept.",
            style = MaterialTheme.typography.bodySmall
        )
        Alertness.weekAverage(this@GameActivity)?.let {
            Text("7-day average: $it %", color = MaterialTheme.colorScheme.primary)
        }
        Button(onClick = {
            if (adsAllowedHere()) Ads.showInterstitial(this@GameActivity) { finish() } else finish()
        }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
    }

    // ---------------- Game 1: Follow the Wisp (memory) ----------------
    @Composable
    private fun MemoryGame(onDone: (Int) -> Unit) {
        val lengths = listOf(3, 4, 5)
        val scope = rememberCoroutineScope()
        var round by remember { mutableIntStateOf(0) }
        var seq by remember { mutableStateOf(listOf<Int>()) }
        var showing by remember { mutableStateOf(true) }
        var lit by remember { mutableIntStateOf(-1) }
        var wrong by remember { mutableIntStateOf(-1) }
        var pos by remember { mutableIntStateOf(0) }
        var correctRounds by remember { mutableIntStateOf(0) }
        var lastTap by remember { mutableLongStateOf(0L) }
        val stepTimes = remember { mutableListOf<Long>() }

        LaunchedEffect(round) {
            val s = mutableListOf<Int>()
            while (s.size < lengths[round]) {
                val n = Random.nextInt(9)
                if (s.isEmpty() || s.last() != n) s.add(n)
            }
            seq = s; pos = 0; wrong = -1; showing = true
            delay(800)
            for (cell in s) { lit = cell; delay(550); lit = -1; delay(250) }
            showing = false
            lastTap = SystemClock.elapsedRealtime()
        }

        fun endRound(ok: Boolean) {
            if (ok) correctRounds++
            if (round + 1 >= lengths.size) {
                val avg = if (stepTimes.isEmpty()) 2000.0 else stepTimes.average()
                val speed = ((1600.0 - avg) / 1100.0).coerceIn(0.0, 1.0)
                val acc = correctRounds / lengths.size.toDouble()
                onDone((acc * 70 + speed * 30 * acc).toInt())
            } else {
                round++
            }
        }

        Text("✨ Follow the Wisp", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Round ${round + 1} of ${lengths.size}")
        Text(if (showing) "Watch…" else "Your turn: $pos / ${seq.size}", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            for (r in 0 until 3) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    for (col in 0 until 3) {
                        val idx = r * 3 + col
                        val color = when (idx) {
                            wrong -> Color(0xFFE53935)
                            lit -> Color(0xFF8FE3FF)
                            else -> Color(0xFF1D2B5C)
                        }
                        Box(
                            Modifier.size(84.dp).clip(CircleShape).background(color)
                                .clickable(enabled = !showing && wrong < 0) {
                                    val now = SystemClock.elapsedRealtime()
                                    if (idx == seq[pos]) {
                                        stepTimes.add(now - lastTap)
                                        lastTap = now
                                        lit = idx
                                        scope.launch { delay(150); if (lit == idx) lit = -1 }
                                        pos++
                                        if (pos >= seq.size) {
                                            showing = true
                                            scope.launch { delay(400); endRound(true) }
                                        }
                                    } else {
                                        wrong = idx
                                        scope.launch { delay(700); endRound(false) }
                                    }
                                }
                        )
                    }
                }
            }
        }
    }

    // ---------------- Game 2: Quick Maths ----------------
    private data class Question(val text: String, val answer: Int, val options: List<Int>)

    private fun makeQuestion(): Question {
        val (text, ans) = when (Random.nextInt(3)) {
            0 -> { val a = Random.nextInt(12, 60); val b = Random.nextInt(5, 40); "$a + $b" to a + b }
            1 -> { val a = Random.nextInt(30, 99); val b = Random.nextInt(5, a - 10); "$a − $b" to a - b }
            else -> { val a = Random.nextInt(3, 10); val b = Random.nextInt(3, 13); "$a × $b" to a * b }
        }
        val opts = mutableSetOf(ans)
        val deltas = listOf(-10, -3, -2, -1, 1, 2, 3, 10)
        while (opts.size < 4) {
            val d = ans + deltas.random()
            if (d >= 0) opts.add(d)
        }
        return Question(text, ans, opts.shuffled())
    }

    @Composable
    private fun MathsGame(onDone: (Int) -> Unit) {
        val total = 5
        var index by remember { mutableIntStateOf(0) }
        var q by remember { mutableStateOf(makeQuestion()) }
        var correct by remember { mutableIntStateOf(0) }
        var shownAt by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
        val times = remember { mutableListOf<Long>() }

        Text("➗ Quick Maths", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Question ${index + 1} of $total")
        Box(Modifier.height(30.dp))
        Text("${q.text} = ?", fontSize = 44.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.height(20.dp))
        for (row in 0 until 2) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (col in 0 until 2) {
                    val opt = q.options[row * 2 + col]
                    OutlinedButton(
                        onClick = {
                            times.add(SystemClock.elapsedRealtime() - shownAt)
                            if (opt == q.answer) correct++
                            if (index + 1 >= total) {
                                val avg = times.average()
                                val speed = ((8000.0 - avg) / 6000.0).coerceIn(0.0, 1.0)
                                val acc = correct / total.toDouble()
                                onDone((acc * 70 + speed * 30 * acc).toInt())
                            } else {
                                index++
                                q = makeQuestion()
                                shownAt = SystemClock.elapsedRealtime()
                            }
                        },
                        modifier = Modifier.weight(1f).height(72.dp)
                    ) { Text("$opt", fontSize = 26.sp) }
                }
            }
        }
    }

    // ---------------- Game 3: Catch the Wisp (reaction) ----------------
    @Composable
    private fun ColumnScope.CatchGame(onDone: (Int) -> Unit) {
        val total = 8
        var caught by remember { mutableIntStateOf(0) }
        var misses by remember { mutableIntStateOf(0) }
        var target by remember { mutableStateOf<Offset?>(null) }   // position as 0..1 fractions
        var shownAt by remember { mutableLongStateOf(0L) }
        val reactions = remember { mutableListOf<Long>() }

        LaunchedEffect(caught) {
            if (caught >= total) {
                // median ignores one slow outlier; scale: 450 ms or faster = 100 %, 1.5 s or slower = 0 %
                val sorted = reactions.sorted()
                val median = if (sorted.isEmpty()) 1500.0 else sorted[sorted.size / 2].toDouble()
                val base = ((1500.0 - median) / 1050.0).coerceIn(0.0, 1.0) * 100
                onDone((base - (misses * 4).coerceAtMost(30)).toInt())
            } else {
                target = null
                delay(Random.nextLong(500, 1400))
                target = Offset(Random.nextFloat(), Random.nextFloat())
                shownAt = SystemClock.elapsedRealtime()
            }
        }

        Text("🎯 Catch the Wisp", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Caught $caught / $total   ·   misses $misses")
        BoxWithConstraints(
            Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(24.dp)).background(Color(0xFF0E1630))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    if (caught < total) misses++
                }
        ) {
            val t = target
            if (t != null) {
                val sz = 92.dp
                Box(
                    Modifier.offset(x = (maxWidth - sz) * t.x, y = (maxHeight - sz) * t.y).size(sz)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                            if (target != null) {
                                reactions.add(SystemClock.elapsedRealtime() - shownAt)
                                target = null
                                caught++
                            }
                        }
                ) { WispGlow(flashKey = 0, size = sz, palette = appTheme) }
            }
        }
    }
}
