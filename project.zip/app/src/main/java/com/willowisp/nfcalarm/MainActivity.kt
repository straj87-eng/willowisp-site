package com.willowisp.nfcalarm

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.provider.OpenableColumns
import android.net.Uri
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import android.os.Bundle
import com.google.android.play.core.review.ReviewManagerFactory
import android.os.PowerManager
import android.provider.Settings
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.RadioButton
import androidx.compose.ui.text.style.TextDecoration
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Purpose { NONE, REGISTER }

// Pages on your website (set the SITE_URL secret on GitHub)
private val TERMS_URL = BuildConfig.SITE_URL + "/terms.html"
private val PRIVACY_URL = BuildConfig.SITE_URL + "/privacy.html"
private const val SUPPORT_EMAIL = "willowispapp@gmail.com"

class MainActivity : ComponentActivity(), NfcAdapter.ReaderCallback {

    private var nfc: NfcAdapter? = null
    private var purpose by mutableStateOf(Purpose.NONE)
    private var scanMsg by mutableStateOf("")
    private var pendingTag by mutableStateOf<TagInfo?>(null)
    private var pro by mutableStateOf(false)
    private var loggedIn by mutableStateOf(false)
    private var nickname by mutableStateOf("")
    private var marketing by mutableStateOf(false)
    private var signingIn by mutableStateOf(false)
    private var online by mutableStateOf(true)
    private var loginDeferred by mutableStateOf(false)     // offline at first launch: use now, sign in later
    private var pendingLogin = false                        // tapped "Continue with Google" while offline
    private var pendingMarketing = false
    private var netCallback: android.net.ConnectivityManager.NetworkCallback? = null
    private var billingTick by mutableIntStateOf(0)
    private var showPro by mutableStateOf(false)
    private lateinit var billing: Billing
    private var tags by mutableStateOf(listOf<TagInfo>())
    private var sets by mutableStateOf(listOf(Store.DEFAULT_SET))
    private var currentSet by mutableStateOf(Store.DEFAULT_SET)
    private var soundForAlarm = -1
    private var onboarded by mutableStateOf(true)
    private var appTheme by mutableStateOf(Themes.ALL[0])
    private var showGuide by mutableStateOf(false)
    private var tab by mutableIntStateOf(0)
    private var arming by mutableStateOf<AlarmItem?>(null)   // alarm waiting for "which tags tonight?"
    private var crashText by mutableStateOf<String?>(null)
    private var bedVersion by mutableIntStateOf(0)
    private var alarms by mutableStateOf(listOf<AlarmItem>())
    private var floatText by mutableStateOf("")
    private var floatKey by mutableIntStateOf(0)
    private var resumeTick by mutableIntStateOf(0)

    // System alarm-sound picker (shows all built-in alarm tones with preview)
    private val ringtonePicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val a = alarms.firstOrNull { it.id == soundForAlarm }
            if (a != null && res.resultCode == RESULT_OK) {
                @Suppress("DEPRECATION")
                val uri: Uri? = res.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                if (uri == null) {
                    saveAlarm(a.copy(soundUri = "", soundName = "Will-O-Wisp chime"))
                } else if (uri == Settings.System.DEFAULT_ALARM_ALERT_URI) {
                    saveAlarm(a.copy(soundUri = uri.toString(), soundName = "Phone's default alarm"))
                } else {
                    val title = try { RingtoneManager.getRingtone(this, uri)?.getTitle(this) } catch (e: Exception) { null }
                    saveAlarm(a.copy(soundUri = uri.toString(), soundName = title ?: "Alarm sound"))
                }
            }
        }

    // Custom sound from the user's own files (mp3, m4a, ogg…)
    private val filePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val a = alarms.firstOrNull { it.id == soundForAlarm }
            if (a != null && uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) { }
                saveAlarm(a.copy(soundUri = uri.toString(), soundName = displayName(uri)))
            }
        }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { resumeTick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfc = NfcAdapter.getDefaultAdapter(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            Store.getStr(this, "notifAsked") != "1"
        ) {
            Store.putStr(this, "notifAsked", "1")
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        Analytics.updateUserProperties(this)
        reload()
        pro = Store.isPro(this)
        loggedIn = Account.isLoggedIn()
        online = isOnline(this)
        loginDeferred = !loggedIn && Store.getStr(this, "loginDeferred") == "1" && !online
        watchNetwork()
        nickname = Account.nickname(this)
        marketing = Store.getStr(this, "marketing") == "true"
        billing = Billing(this, onLoaded = { billingTick++ }, onPro = { grantPro() }, onProLost = { revokePlayPro() })
        billing.start()
        Ads.init(this)
        // clear a stale "ringing" flag (e.g. the app was force-stopped mid-alarm without a reboot)
        Store.ringingSince(this).let { since ->
            if (since > 0 && !AlarmService.state.value.active && System.currentTimeMillis() - since > 3 * 60 * 60 * 1000L) {
                Store.setRingingSince(this, 0L)
            }
        }
        crashText = crashReport()
        if (intent?.getBooleanExtra("openPro", false) == true) showPro = true
        ensureSingleAlarm()
        onboarded = Store.onboarded(this)
        appTheme = Themes.current(this)
        Habit.applyFreezes(this)
        AlarmScheduler.rescheduleAll(this)
        Bedtime.schedule(this)
        showNextAlarmFloat()
        setComposeContent {
            MaterialTheme(colorScheme = Themes.scheme(appTheme)) {
                App()
            }
        }
    }

    /** Tracks connectivity; signs in automatically when the internet comes back after an offline tap. */
    private fun watchNetwork() {
        val cm = getSystemService(android.net.ConnectivityManager::class.java) ?: return
        val cb = object : android.net.ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: android.net.Network) {
                runOnUiThread {
                    online = true
                    if (pendingLogin && !loggedIn) { pendingLogin = false; login(pendingMarketing) }
                }
            }
            override fun onLost(network: android.net.Network) {
                runOnUiThread { online = isOnline(this@MainActivity) }
            }
        }
        try { cm.registerDefaultNetworkCallback(cb); netCallback = cb } catch (_: Exception) { }
    }

    override fun onDestroy() {
        netCallback?.let {
            try { getSystemService(android.net.ConnectivityManager::class.java)?.unregisterNetworkCallback(it) } catch (_: Exception) { }
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("openPro", false)) showPro = true
    }

    override fun onResume() {
        super.onResume()
        HabitWidget.updateAll(this)   // also locks the widget again when ad-Pro expires
        maybeAskForReview()
        Funnel.checkReturn(this)
        online = isOnline(this)
        if (!loggedIn && loginDeferred && online) loginDeferred = false   // back online: sign-in required now
        Store.getStr(this, "penaltyNotice").takeIf { it.isNotBlank() }?.let {
            float(it)
            Store.putStr(this, "penaltyNotice", "")
        }
        pro = Store.isPro(this)
        appTheme = Themes.current(this)
        Habit.applyFreezes(this)
        resumeTick++
        nfc?.enableReaderMode(
            this, this,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V,
            null
        )
    }

    override fun onPause() {
        super.onPause()
        nfc?.disableReaderMode(this)
    }

    // ---------- NFC ----------
    override fun onTagDiscovered(tag: Tag) {
        if (purpose == Purpose.REGISTER) {
            val uid = uidHex(tag.id)
            runOnUiThread { handleScanned(uid) }
        }
    }

    // ---------- tag registration + Pro ----------
    /** Any brand of NFC tag works. Free: 2 tags in total. Pro: up to 10 per tag set. */
    private fun handleScanned(uid: String) {
        if (tags.any { it.uid == uid }) { scanMsg = "Already registered on this phone"; return }
        if (tags.count { it.set == currentSet } >= Store.MAX_TAGS) { scanMsg = "Maximum ${Store.MAX_TAGS} tags in $currentSet"; return }
        if (!pro && tags.size >= Store.FREE_TAGS) {
            scanMsg = "The free version allows ${Store.FREE_TAGS} tags. Unlock Pro for up to ${Store.MAX_TAGS} per set."
            showPro = true
            return
        }
        acceptTag(TagInfo(uid, ""))
    }

    private fun acceptTag(t: TagInfo) {
        pendingTag = t.copy(set = currentSet)
        purpose = Purpose.NONE
        scanMsg = ""
    }

    /** Pro until tomorrow 12:00 (or today 12:00 if it's before 6 am) after a rewarded ad. */
    /** Rewarded ad: everything in Pro (including the widget) for 18 hours, once a week. */
    private fun grantProByAd() {
        Analytics.log(this, "pro_ad_unlock")
        Store.grantAdPro(this)
        pro = true
        appTheme = Themes.current(this)
        HabitWidget.updateAll(this)
        float("🎬 Pro unlocked for ${Store.AD_PRO_HOURS} hours")
    }

    private fun adProNextText(): String {
        val days = ((Store.adProAvailableAt(this) - System.currentTimeMillis()) / (24L * 60 * 60 * 1000)).toInt() + 1
        return if (days <= 1) "tomorrow" else "in $days days"
    }

    /** Play says the subscription ended (and no lifetime purchase): remove Pro bought on Play. */
    private fun revokePlayPro() {
        if (Store.hasRealPro(this) && Store.proSource(this) == "play") {
            Store.setPro(this, false)
            HabitWidget.updateAll(this)
            pro = Store.isPro(this)
            appTheme = Themes.current(this)
        }
    }

    private fun grantPro() {
        if (!pro) float("✦ Pro unlocked")
        Store.setPro(this, true, "play")
        HabitWidget.updateAll(this)
        pro = true
        appTheme = Themes.current(this)
    }

    /**
     * After a "Don't allow", Android stops showing the permission pop-up, so the button
     * opens the app's notification settings instead.
     */
    private fun askNotifications() {
        val asked = Store.getStr(this, "notifAsked") == "1"
        if (!asked || shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
            Store.putStr(this, "notifAsked", "1")
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            openSettings(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }
    }

    /** If the app crashed last time, offer to email the crash details to support. */
    private fun crashReport(): String? {
        val f = java.io.File(filesDir, WispApp.CRASH_FILE)
        return if (f.exists()) f.readText() else null
    }

    private fun sendCrashReport(text: String) {
        java.io.File(filesDir, WispApp.CRASH_FILE).delete()
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(SUPPORT_EMAIL))
            .putExtra(Intent.EXTRA_SUBJECT, "Will-O-Wisp crash report")
            .putExtra(Intent.EXTRA_TEXT, "What were you doing when it closed?\n\n\n---\n$text")
        try { startActivity(i) } catch (e: Exception) { float("No email app found") }
    }

    private fun activeCount(set: String) = tags.count { it.set == set && it.enabled }

    /** Switching the alarm on: ask which tags are with you tonight, or warn if the set is empty. */
    private fun armAlarm(a: AlarmItem) {
        if (a.noTags) { saveAlarm(a.copy(enabled = true)); return }
        val usable = sets.filter { activeCount(it) > 0 }
        if (usable.size == 1 && usable[0] == a.tagSet) {
            saveAlarm(a.copy(enabled = true))
        } else {
            arming = a   // several sets, a different set, or an empty set → dialog
        }
    }

    @Composable
    private fun ArmDialog(a: AlarmItem) {
        val usable = sets.filter { activeCount(it) > 0 }.sortedBy { if (it == a.tagSet) 0 else 1 }
        AlertDialog(
            onDismissRequest = { arming = null },
            title = { Text(if (usable.isEmpty()) "No active tags" else "Which tags are with you tonight?") },
            text = {
                if (usable.isEmpty()) {
                    Text("Your ${a.tagSet} set has no active tags, so tomorrow's alarm would only have a Stop button and won't count towards your streak.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        usable.forEach { set ->
                            val label = (if (set == Store.DEFAULT_SET) "🏠 " else if (set.equals("Travel", true)) "🧳 " else "🏷 ") +
                                "$set (${activeCount(set)} tags)"
                            if (set == a.tagSet) {
                                Button(onClick = { arming = null; saveAlarm(a.copy(enabled = true, tagSet = set)) },
                                    modifier = Modifier.fillMaxWidth()) { Text(label) }
                            } else {
                                OutlinedButton(onClick = { arming = null; saveAlarm(a.copy(enabled = true, tagSet = set)) },
                                    modifier = Modifier.fillMaxWidth()) { Text(label) }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (usable.isEmpty()) {
                    TextButton(onClick = { arming = null; tab = 1 }) { Text("Go to Tags") }
                }
            },
            dismissButton = {
                if (usable.isEmpty()) {
                    TextButton(onClick = { arming = null; saveAlarm(a.copy(enabled = true)) }) { Text("Arm anyway") }
                } else {
                    TextButton(onClick = { arming = null }) { Text("Cancel") }
                }
            }
        )
    }

    /** True if removing/pausing this tag would leave the armed alarm's set with no active tags. */
    private fun isLastArmedTag(t: TagInfo): Boolean {
        val a = alarms.firstOrNull() ?: return false
        return a.enabled && !a.noTags && t.enabled && t.set == a.tagSet && activeCount(t.set) <= 1
    }

    private fun login(wantsMarketing: Boolean) {
        if (!isOnline(this)) {
            online = false
            pendingLogin = true
            pendingMarketing = wantsMarketing
            float("You're offline — we'll sign you in as soon as you're connected")
            return
        }
        signingIn = true
        lifecycleScope.launch {
            try {
                Account.signIn(this@MainActivity, wantsMarketing)
                loggedIn = true
                nickname = Account.nickname(this@MainActivity)
                marketing = wantsMarketing
                loginDeferred = false
                Store.putStr(this@MainActivity, "loginDeferred", "")
                Analytics.log(this@MainActivity, "login", "marketing" to wantsMarketing)
            } catch (e: Exception) {
                float(if (!isOnline(this@MainActivity)) "You're offline — connect to sign in"
                      else "Sign-in didn't finish — tap Continue with Google to try again")
            } finally {
                signingIn = false
            }
        }
    }

    private fun changeMarketing(on: Boolean) {
        lifecycleScope.launch {
            try {
                Account.setMarketing(this@MainActivity, on)
                marketing = on
                float(if (on) "📬 Your 21-day wake-up plan is on its way" else "Unsubscribed from emails")
            } catch (e: Exception) {
                float("Couldn't update (check internet)")
            }
        }
    }

    private fun logout() {
        lifecycleScope.launch {
            Account.signOut(this@MainActivity)
            loggedIn = false
        }
    }

    private fun deleteMyAccount() {
        lifecycleScope.launch {
            try {
                Account.deleteAccount(this@MainActivity)
                loggedIn = false
                float("Your account has been deleted")
            } catch (e: Exception) {
                float("Couldn't delete right now (check internet) — or email $SUPPORT_EMAIL")
            }
        }
    }

    // ---------- helpers ----------
    private fun reload() {
        tags = Store.tags(this)
        alarms = Store.alarms(this)
        sets = Store.sets(this)
        if (currentSet !in sets) currentSet = sets.firstOrNull() ?: Store.DEFAULT_SET
    }

    /** The app has exactly one alarm: create it on first launch, remove extras from older versions. */
    private fun ensureSingleAlarm() {
        val list = Store.alarms(this)
        if (list.isEmpty()) {
            val set = sets.firstOrNull { s -> tags.any { it.set == s } } ?: Store.DEFAULT_SET
            Store.upsertAlarm(
                this,
                AlarmItem(1, 6, 0, emptySet(), enabled = false, crazy = false, random = false, tagSet = set)
            )
        }
        Store.alarms(this).firstOrNull()?.let {   // older versions had repeat days; now always one-shot
            if (it.days.isNotEmpty()) Store.upsertAlarm(this, it.copy(days = emptySet()))
        }
        if (list.size > 1) {
            val keep = list.firstOrNull { it.enabled } ?: list.first()
            list.filter { it.id != keep.id }.forEach {
                AlarmScheduler.cancel(this, it.id)
                Store.deleteAlarm(this, it.id)
            }
        }
        reload()
    }

    private fun displayName(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "My sound"
    } catch (e: Exception) {
        "My sound"
    }

    private fun pickSystemSound(a: AlarmItem) {
        soundForAlarm = a.id
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Alarm sound")
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
        if (a.soundUri.isNotBlank()) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(a.soundUri))
        try { ringtonePicker.launch(i) } catch (e: Exception) { float("No sound picker on this phone") }
    }

    private fun pickFileSound(a: AlarmItem) {
        soundForAlarm = a.id
        try { filePicker.launch(arrayOf("audio/*")) } catch (e: Exception) { float("No file picker available") }
    }

    private fun nextLabel(a: AlarmItem): String {
        if (!a.enabled) return "Off · switch on for your next wake-up"
        val d = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(AlarmScheduler.nextTrigger(a)))
        return "Rings $d · " + if (a.noTags) "no tags" else "${a.tagSet} tags"
    }

    private fun float(text: String) {
        floatText = text
        floatKey++
    }

    private fun showNextAlarmFloat() {
        AlarmScheduler.nextEnabled(this)?.let { float(AlarmScheduler.untilText(it)) }
    }

    private fun saveAlarm(a: AlarmItem) {
        if (a.enabled) Funnel.once(this, "alarm_created",
            "tags" to (if (a.noTags) 0 else activeCount(a.tagSet)), "mode" to (if (a.crazy) "crazy" else "normal"))
        Store.upsertAlarm(this, a)
        AlarmScheduler.schedule(this, a)
        reload()
        if (a.enabled) float(AlarmScheduler.untilText(AlarmScheduler.nextTrigger(a)))
    }

    private fun saveTags(list: List<TagInfo>) {
        if (list.size > tags.size) Analytics.log(this, "tag_registered", "total_tags" to list.size)
        Store.saveTags(this, list)
        Analytics.updateUserProperties(this)
        tags = list
    }

    /** Swap two tags (by UID) in the full list, so order within a set changes. */
    private fun swapTags(a: String, b: String) {
        val l = tags.toMutableList()
        val i = l.indexOfFirst { it.uid == a }
        val j = l.indexOfFirst { it.uid == b }
        if (i < 0 || j < 0) return
        val t = l[i]; l[i] = l[j]; l[j] = t
        saveTags(l)
    }

    private fun pickTime(h: Int, m: Int, onPick: (Int, Int) -> Unit) {
        TimePickerDialog(this, { _, hh, mm -> onPick(hh, mm) }, h, m, DateFormat.is24HourFormat(this)).show()
    }

    private fun testAlarm(a: AlarmItem) {
        startForegroundService(Intent(this, AlarmService::class.java).putExtra("id", a.id).putExtra("test", true))
        startActivity(Intent(this, RingActivity::class.java))
    }

    private fun openSettings(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun copy(text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("key", text))
        float("Copied")
    }

    private fun fmt(h: Int, m: Int) = "%02d:%02d".format(h, m)

    // ---------- UI ----------
    @Composable
    private fun App() {
        when {
            !loggedIn && !loginDeferred -> LoginScreen()
            !onboarded -> Onboarding()
            else -> MainScreen()
        }
            crashText?.let { t ->
                AlertDialog(
                    onDismissRequest = { crashText = null },
                    title = { Text("Sorry — the app closed unexpectedly") },
                    text = { Text("Send us the technical details so we can fix it? Your email app opens with the report ready; nothing is sent automatically.") },
                    confirmButton = { TextButton(onClick = { crashText = null; sendCrashReport(t) }) { Text("Send report") } },
                    dismissButton = {
                        TextButton(onClick = {
                            crashText = null
                            java.io.File(filesDir, WispApp.CRASH_FILE).delete()
                        }) { Text("No thanks") }
                    }
                )
            }
    }

    /** Required sign-in, shown before anything else. */
    @Composable
    private fun LoginScreen() {
        var wantsMarketing by remember { mutableStateOf(false) }
        Box(Modifier.fillMaxSize()) {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
                ) {
                    WispGlow(flashKey = 0, size = 170.dp, palette = appTheme)
                    Text("Will-O-Wisp", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "The alarm you have to walk to. Sign in to save your streaks, badges and Pro.",
                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge
                    )
                    Button(
                        onClick = { login(wantsMarketing) },
                        enabled = !signingIn,
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) { Text(if (signingIn) "Signing in…" else "Continue with Google", fontSize = 18.sp) }
                    if (!online) {
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("📶 You're offline", fontWeight = FontWeight.Bold)
                                Text(
                                    "Connect to Wi-Fi or mobile data to sign in — it's only needed once. " +
                                        "If you tap Continue with Google now, we'll finish signing you in as soon as you're connected.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                TextButton(onClick = {
                                    Store.putStr(this@MainActivity, "loginDeferred", "1")
                                    loginDeferred = true
                                }) { Text("Continue for now — sign in later") }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Checkbox(checked = wantsMarketing, onCheckedChange = { wantsMarketing = it })
                        Column {
                            Text("Send me the free 21-day wake-up plan", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Plus tips and member-only offers. Optional · unsubscribe anytime.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Text(
                        "By continuing you agree to our Terms and Privacy policy.",
                        style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center
                    )
                    Row {
                        TextButton(onClick = { openUrl(TERMS_URL) }) { Text("Terms") }
                        TextButton(onClick = { openUrl(PRIVACY_URL) }) { Text("Privacy") }
                    }
                }
            }
            FloatingText(Modifier.align(Alignment.Center))
        }
    }

    @Composable
    private fun MainScreen() {
        val drawerState = rememberDrawerState(DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(Modifier.width(330.dp)) {
                    LazyColumn(
                        contentPadding = PaddingValues(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item { DrawerHeader() }
                        item { BedtimeCard() }
                        item { ThemeCard() }
                        item { SettingsCard() }
                    }
                }
            }
        ) {
        Box(Modifier.fillMaxSize()) {
            Scaffold(
                topBar = {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { scope.launch { drawerState.open() } }) { Text("☰", fontSize = 26.sp) }
                        Text("Hi $nickname 👋", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (pro) Text("✦ Pro", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(end = 12.dp))
                    }
                },
                bottomBar = {
                    Column {
                    if (!pro && Ads.ready) BannerAd()
                    NavigationBar {
                        NavigationBarItem(
                            selected = tab == 0, onClick = { tab = 0; purpose = Purpose.NONE },
                            icon = { Text("⏰") }, label = { Text("Alarms") }
                        )
                        NavigationBarItem(
                            selected = tab == 1, onClick = { tab = 1; purpose = Purpose.NONE },
                            icon = { Text("🏷") }, label = { Text("Tags") }
                        )
                        NavigationBarItem(
                            selected = tab == 2, onClick = { tab = 2; purpose = Purpose.NONE },
                            icon = { Text("❓") }, label = { Text("Help") }
                        )
                    }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> AlarmsTab()
                        1 -> TagsTab()
                        else -> HelpTab()
                    }
                }
            }
            if (showPro) Paywall()
            if (showGuide) SetupGuide()
            arming?.let { ArmDialog(it) }
            FloatingText(Modifier.align(Alignment.Center))
        }
        }

        val pt = pendingTag
        if (pt != null) {
            NameDialog("Name this tag (${pt.set})", "Tag ${tags.count { it.set == pt.set } + 1}", onDismiss = { pendingTag = null }) { n ->
                saveTags(tags + pt.copy(name = n))
                pendingTag = null
            }
        }
    }

    @Composable
    private fun DrawerHeader() {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(nickname.take(1).uppercase(), color = MaterialTheme.colorScheme.onPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(nickname, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(Account.email() ?: "", style = MaterialTheme.typography.bodySmall)
                if (pro) Text("✦ Pro", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }
    }

    private fun sleepFor(bedH: Int, bedM: Int, wakeH: Int, wakeM: Int): String {
        val mins = ((wakeH * 60 + wakeM) - (bedH * 60 + bedM) + 24 * 60) % (24 * 60)
        return if (mins % 60 == 0) "${mins / 60} h" else "${mins / 60} h ${mins % 60} min"
    }

    @Composable
    private fun SettingRow(label: String, value: String, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = onClick) { Text(value, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
        }
    }

    /** First launch: welcome badge + bedtime and wake-up setup. */
    @Composable
    private fun Onboarding() {
        val ctx = this@MainActivity
        val alarm = alarms.firstOrNull()
        var bedH by remember { mutableIntStateOf(Store.bedHour(ctx)) }
        var bedM by remember { mutableIntStateOf(Store.bedMinute(ctx)) }
        var lead by remember { mutableIntStateOf(Store.bedLeadMin(ctx)) }
        var wakeH by remember { mutableIntStateOf(alarm?.hour ?: 6) }
        var wakeM by remember { mutableIntStateOf(alarm?.minute ?: 0) }
        var goal by remember { mutableStateOf(Store.getStr(ctx, "goal")) }
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Image(
                    painter = painterResource(R.drawable.badge_welcome),
                    contentDescription = "Will-O-Wisp NFC Alarm badge",
                    modifier = Modifier.size(230.dp)
                )
                Text("Hi $nickname! 👋", fontWeight = FontWeight.Bold, fontSize = 24.sp, textAlign = TextAlign.Center)
                Text("🌱 Badge unlocked: Wisp Awakened", fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center)
                Text(
                    "You installed Will-O-Wisp. Your bed is already nervous.",
                    textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "No snooze, no tapping from bed. Will-O-Wisp only stops when you walk to your tags — so the first thing you do every morning is move.",
                    textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium
                )
                HorizontalDivider()
                Text("What gets you up in the morning?", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Goals.ALL.forEach { g ->
                        val label = "${g.emoji}  ${g.label}"
                        if (goal == g.id) {
                            Button(onClick = { goal = g.id }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                        } else {
                            OutlinedButton(onClick = { goal = g.id }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                        }
                    }
                }
                Text("We'll remind you of it when the alarm rings.", style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                Text("Set up your night and morning", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                SettingRow("🌙 Bedtime", fmt(bedH, bedM)) { pickTime(bedH, bedM) { h, m -> bedH = h; bedM = m } }
                Choice("Remind", listOf("1 h before", "2 h before"), if (lead == 120) 1 else 0) {
                    lead = if (it == 1) 120 else 60
                }
                SettingRow("⏰ Wake-up", fmt(wakeH, wakeM)) { pickTime(wakeH, wakeM) { h, m -> wakeH = h; wakeM = m } }
                Text(
                    "That's ${sleepFor(bedH, bedM, wakeH, wakeM)} of sleep. One alarm, no snooze, no excuses.",
                    style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center
                )
                Button(
                    onClick = {
                        Store.saveBedtime(ctx, bedH, bedM, lead, true)
                        if (goal.isNotBlank()) Goals.set(ctx, goal)
                        alarm?.let { Store.upsertAlarm(ctx, it.copy(hour = wakeH, minute = wakeM)) }
                        Store.setOnboarded(ctx)
                        reload()
                        AlarmScheduler.rescheduleAll(ctx)
                        Bedtime.schedule(ctx)
                        onboarded = true
                        showGuide = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Get started") }
                Text(
                    "Next: register your tags in the Tags tab, then switch the alarm on.",
                    style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center
                )
            }
        }
    }

    @Composable
    private fun BedtimeCard() {
        val ctx = this@MainActivity
        val v = bedVersion   // recompose after changes
        val h = Store.bedHour(ctx)
        val m = Store.bedMinute(ctx)
        val lead = Store.bedLeadMin(ctx)
        val on = Store.bedOn(ctx)
        val alarm = alarms.firstOrNull()
        fun save(nh: Int = h, nm: Int = m, nl: Int = lead, non: Boolean = on) {
            Store.saveBedtime(ctx, nh, nm, nl, non)
            Bedtime.schedule(ctx)
            bedVersion++
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { pickTime(h, m) { nh, nm -> save(nh = nh, nm = nm) } }) {
                        Text("🌙 Bedtime ${fmt(h, m)}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "${sleepFor(h, m, alarm?.hour ?: 6, alarm?.minute ?: 0)} of sleep · tap to change" +
                                (if (v < 0) "" else ""),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = on, onCheckedChange = { save(non = it) })
                }
                if (on) {
                    Choice("Remind", listOf("1 h before", "2 h before"), if (lead == 120) 1 else 0) {
                        save(nl = if (it == 1) 120 else 60)
                    }
                }
            }
        }
    }

    /**
     * Google Play review card after the 3rd full wake-up, then again every 3 days.
     * Google doesn't tell apps whether a review was left (and limits how often the card can appear),
     * so asking stops once the user taps "Rate us" (opens the Play listing) or after 6 attempts.
     */
    private fun maybeAskForReview() {
        if (Store.reviewDone(this) || Store.reviewAsks(this) >= 6) return
        if (Habit.total(this) < 3) return
        val threeDays = 3L * 24 * 60 * 60 * 1000
        if (System.currentTimeMillis() - Store.reviewLastAsk(this) < threeDays) return
        if (getSystemService(android.app.KeyguardManager::class.java).isKeyguardLocked) return
        val manager = ReviewManagerFactory.create(this)
        manager.requestReviewFlow().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                Store.noteReviewAsk(this)
                manager.launchReviewFlow(this, task.result)
            }
        }
    }

    /** "Rate us" button: opens the Play Store listing and stops further review prompts. */
    private fun rateUs() {
        Store.setReviewDone(this)
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
        try { startActivity(market) } catch (e: Exception) {
            openUrl("https://play.google.com/store/apps/details?id=$packageName")
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
    }

    /** Full-screen Pro paywall: one yearly plan with a free trial. */
    @Composable
    private fun Paywall() {
        val ctx = this@MainActivity
        val tick = billingTick
        val p = if (billing.loaded && tick >= 0) billing.prices() else null
        val trial = p?.trialDays ?: 0
        BackHandler { showPro = false }
        LaunchedEffect(Unit) { Analytics.log(ctx, "pro_view", "pro_now" to pro) }

        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(Modifier.fillMaxWidth()) {
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { showPro = false }) { Text("✕", fontSize = 22.sp) }
                }
                WispGlow(flashKey = 0, size = 120.dp, palette = appTheme)
                Text("Will-O-Wisp Pro", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Make every morning a walk you can't skip.",
                    style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center
                )
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(
                        "Up to ${Store.MAX_TAGS} tags per set — the full 5-tag walk and more",
                        "Crazy mode & random tag order",
                        "Streak freeze — ${Habit.FREEZES_PER_MONTH} a month",
                        "Premium themes: Ember, Aurora, Royal, Dawn",
                        "Home-screen habit widget",
                        "No ads"
                    ).forEach { Text("✓  $it") }
                }

                PlanCard(
                    selected = true,
                    title = "Yearly",
                    badge = if (trial > 0) "$trial days free" else null,
                    subtitle = "one simple plan · cancel anytime",
                    price = p?.yearly?.let { "$it / year" } ?: "—",
                    strike = null
                ) { }

                if (p == null) {
                    Text(
                        "Purchases are available in the Google Play version of the app.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                Button(
                    onClick = { if (billing.buy()) showPro = false else float("Available in the Google Play version") },
                    enabled = p != null,
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Text(if (trial > 0) "Start $trial-day free trial" else "Subscribe", fontSize = 18.sp)
                }
                Text(
                    (if (trial > 0) "Free for $trial days, then " else "") +
                        "${p?.yearly ?: "the yearly price"} per year. Renews automatically. Cancel anytime in Google Play.",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center
                )
                if (!Store.hasRealPro(ctx)) {
                    if (Store.canUseAdPro(ctx)) {
                        if (Ads.rewardedReady) {
                            TextButton(onClick = {
                                showPro = false
                                Ads.showRewarded(ctx) { grantProByAd() }
                            }) { Text("🎬 Watch a short ad — all of Pro free for ${Store.AD_PRO_HOURS} hours") }
                            Text("Once a week", style = MaterialTheme.typography.labelSmall)
                        }
                    } else {
                        Text(
                            "🎬 Free Pro by ad: next one available ${adProNextText()}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { billing.restore(); float("Checking Google Play…") }) { Text("Restore") }
                    TextButton(onClick = { openUrl(TERMS_URL) }) { Text("Terms") }
                    TextButton(onClick = { openUrl(PRIVACY_URL) }) { Text("Privacy") }
                }
            }
        }
    }

    @Composable
    private fun PlanCard(
        selected: Boolean,
        title: String,
        badge: String?,
        subtitle: String,
        price: String,
        strike: String?,
        onClick: () -> Unit
    ) {
        Card(
            Modifier.fillMaxWidth().clickable(onClick = onClick),
            border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
            colors = CardDefaults.cardColors(
                containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = selected, onClick = onClick)
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        if (badge != null) {
                            Spacer(Modifier.width(8.dp))
                            Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary) {
                                Text(
                                    badge, fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(subtitle, style = MaterialTheme.typography.bodySmall)
                }
                Column(horizontalAlignment = Alignment.End) {
                    if (strike != null) {
                        Text(strike, style = MaterialTheme.typography.bodySmall, textDecoration = TextDecoration.LineThrough)
                    }
                    Text(price, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
        }
    }

    @Composable
    private fun FloatingText(modifier: Modifier) {
        var visible by remember { mutableStateOf(false) }
        LaunchedEffect(floatKey) {
            if (floatKey > 0) {
                visible = true
                delay(2000)
                visible = false
            }
        }
        AnimatedVisibility(visible = visible, modifier = modifier, enter = fadeIn(), exit = fadeOut()) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.inverseSurface,
                shadowElevation = 8.dp
            ) {
                Text(
                    floatText,
                    color = MaterialTheme.colorScheme.inverseOnSurface,
                    fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp)
                )
            }
        }
    }

    @Composable
    private fun AlarmsTab() {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!loggedIn) {
                item {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Sign in to save your progress", fontWeight = FontWeight.Bold)
                                Text(
                                    if (online) "You're online — sign in now." else "We'll ask again when you're connected.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            TextButton(onClick = { login(marketing) }, enabled = online) { Text("Sign in") }
                        }
                    }
                }
            }
            item { BadgeCard() }
            item { SetupCard() }
            if (!pro) {
                item {
                    Card(Modifier.fillMaxWidth().clickable { showPro = true }) {
                        Column(Modifier.padding(16.dp)) {
                            Text("✦ Unlock Pro — free for 7 days", fontWeight = FontWeight.Bold)
                            Text(
                                "Up to ${Store.MAX_TAGS} tags per set, Crazy mode, Random order, streak freezes, premium themes and no ads.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
            if (tags.isEmpty()) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Text(
                            "No tags registered yet. Open the Tags tab and register any NFC stickers (NTAG213, 215 or 216).",
                            Modifier.padding(16.dp)
                        )
                    }
                }
            }
            // One alarm only — by design. Commit to one wake-up time.
            alarms.firstOrNull()?.let { a -> item(key = a.id) { AlarmCard(a) } }
            item { AlertnessCard() }
            item { HabitCard() }
        }
    }

    @Composable
    private fun AlarmCard(a: AlarmItem) {
        var expanded by remember(a.id) { mutableStateOf(false) }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Collapsed view: time, next ring date, on/off
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { expanded = !expanded }) {
                        Text(fmt(a.hour, a.minute), fontSize = 40.sp, fontWeight = FontWeight.Bold)
                        Text(nextLabel(a), style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "▲" else "▼") }
                    Switch(checked = a.enabled, onCheckedChange = {
                        if (it) armAlarm(a) else saveAlarm(a.copy(enabled = false))
                        if (it) expanded = false
                    })
                }
                if (expanded) {
                    OutlinedButton(onClick = {
                        pickTime(a.hour, a.minute) { h, m -> saveAlarm(a.copy(hour = h, minute = m, enabled = true)) }
                    }) { Text("Change time") }
                    Text(
                        "Rings once, then switches itself off. Switch it on again each night for the next morning.",
                        style = MaterialTheme.typography.bodySmall
                    )

                    TagSetPicker(a)
                    if (!a.noTags) {
                        Choice("Mode", listOf("Normal", if (pro) "Crazy" else "Crazy ✦"), if (a.crazy && pro) 1 else 0) {
                            if (it == 1 && !pro) { showPro = true } else { saveAlarm(a.copy(crazy = it == 1)) }
                        }
                        Text(
                            if (a.crazy && pro) "Keeps ringing until every tag is tapped."
                            else "Each tap silences it. Reach the next tag within 20 s or it rings again.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Choice("Order", listOf("Fixed", if (pro) "Random" else "Random ✦"), if (a.random && pro) 1 else 0) {
                            if (it == 1 && !pro) { showPro = true } else { saveAlarm(a.copy(random = it == 1)) }
                        }
                    }

                    Text("Sound: ${a.soundName}", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (a.soundUri.isNotBlank()) {
                            OutlinedButton(onClick = { saveAlarm(a.copy(soundUri = "", soundName = "Will-O-Wisp chime")) }) { Text("Chime") }
                        }
                        OutlinedButton(onClick = { pickSystemSound(a) }) { Text("Alarm tones") }
                        OutlinedButton(onClick = { pickFileSound(a) }) { Text("My file") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Gradually increase volume")
                            Text("Starts soft, full volume after 60 s", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = a.gradual, onCheckedChange = { saveAlarm(a.copy(gradual = it)) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("🌅 Sunrise mode")
                            Text(
                                "Screen glows warmer & brighter for 10 min before; flashlight joins for the last 3",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(checked = a.sunrise, onCheckedChange = { saveAlarm(a.copy(sunrise = it)) })
                    }
                    if (!a.noTags) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Voice guide")
                                Text("Speaks the next tag's name", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = a.voice, onCheckedChange = { saveAlarm(a.copy(voice = it)) })
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { testAlarm(a) }) { Text("Test now") }
                    }
                }
            }
        }
    }

    @Composable
    private fun TagSetPicker(a: AlarmItem) {
        var open by remember { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Tags", modifier = Modifier.width(56.dp))
            Box {
                OutlinedButton(onClick = { open = true }) {
                    Text((if (a.noTags) "No tags (plain alarm)" else "${a.tagSet} (${tags.count { it.set == a.tagSet }})") + "  ▾")
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    sets.forEach { set ->
                        DropdownMenuItem(
                            text = { Text("$set (${tags.count { it.set == set }} tags)") },
                            onClick = { open = false; saveAlarm(a.copy(tagSet = set, noTags = false)) }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("No tags (plain alarm)") },
                        onClick = { open = false; saveAlarm(a.copy(noTags = true)) }
                    )
                }
            }
        }
    }

    @Composable
    private fun BadgeCard() {
        val tick = resumeTick   // refresh when returning to the app
        val ctx = this@MainActivity
        val b = Habit.latestBadge(ctx)
        val next = Habit.nextBadge(ctx)
        val total = Habit.total(ctx)
        val streak = Habit.streak(ctx)
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(contentAlignment = Alignment.TopEnd) {
                    Image(
                        painter = painterResource(R.drawable.badge_welcome),
                        contentDescription = "Will-O-Wisp NFC Alarm badge",
                        modifier = Modifier.size(170.dp)
                    )
                    if (b != null && b.days > 0) {
                        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
                            Text(b.emoji, fontSize = 32.sp, modifier = Modifier.padding(8.dp))
                        }
                    }
                }
                Text(
                    b?.let { "${it.emoji} You're a ${it.title}!" } ?: "Will-O-Wisp",
                    fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center
                )
                Text(b?.caption ?: "", style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
                Text(
                    "🔥 $streak-day streak · $total wake-ups" +
                        (next?.let { " · ${it.emoji} next in ${it.days - total}" } ?: "") +
                        (if (tick < 0) "" else ""),
                    style = MaterialTheme.typography.labelMedium
                )
                Text(
                    if (pro) "❄️ ${Habit.freezesLeft(ctx)} streak freezes left this month (used automatically)"
                    else "❄️ Streak freeze protects your streak on a missed day — Pro",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = if (pro) Modifier else Modifier.clickable { showPro = true }
                )
                OutlinedButton(onClick = { ShareCard.share(ctx, appTheme) }) { Text("📤 Share my badge") }
            }
        }
    }

    @Composable
    private fun GoalPicker() {
        var open by remember { mutableStateOf(false) }
        var current by remember { mutableStateOf(Goals.current(this@MainActivity)) }
        Box {
            OutlinedButton(onClick = { open = true }) {
                Text((current?.let { "${it.emoji} ${it.label}" } ?: "Choose your reason") + "  ▾")
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                Goals.ALL.forEach { g ->
                    DropdownMenuItem(
                        text = { Text("${g.emoji}  ${g.label}") },
                        onClick = {
                            Goals.set(this@MainActivity, g.id)
                            current = g
                            open = false
                        }
                    )
                }
            }
        }
    }

    @Composable
    private fun AffiliateCard() {
        val ctx = this@MainActivity
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("🛒 Need NFC tags?", fontWeight = FontWeight.SemiBold)
                Text(
                    "An NFC tag is a small sticker with a tiny chip — your phone reads it with a tap, like a contactless card. No battery needed. NTAG213, 215 or 216 (or almost any NFC sticker) works; avoid sticking them directly on metal.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedButton(onClick = {
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Affiliate.url(ctx)))) } catch (_: Exception) { }
                }) { Text("See recommended stickers on ${Affiliate.storeName(ctx)}") }
                Text(
                    "As an Amazon Associate, Will-O-Wisp earns from qualifying purchases.",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }

    @Composable
    private fun SettingsCard() {
        var confirmReset by remember { mutableStateOf(false) }
        var renamingSelf by remember { mutableStateOf(false) }
        var confirmDelete by remember { mutableStateOf(false) }
        if (renamingSelf) {
            NameDialog("What should we call you?", nickname, onDismiss = { renamingSelf = false }) { n ->
                Store.putStr(this@MainActivity, "nickname", n)
                nickname = Account.nickname(this@MainActivity)
                renamingSelf = false
            }
        }
        if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("Delete your account?") },
                text = { Text("This removes your name, email and preferences from our servers and signs you out. Your alarm, tags and badges stay on this phone. An active Pro subscription must be cancelled separately in Google Play.") },
                confirmButton = { TextButton(onClick = { confirmDelete = false; deleteMyAccount() }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
            )
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("⚙️ Settings", fontWeight = FontWeight.Bold, fontSize = 18.sp)

                Text("🎯 What gets you up", fontWeight = FontWeight.SemiBold)
                GoalPicker()
                HorizontalDivider()
                Text("👤 Your account", fontWeight = FontWeight.SemiBold)
                Text(Account.email() ?: "", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { renamingSelf = true }) { Text("Call me: $nickname  ✎") }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("📬 Free 21-day wake-up plan")
                        Text("Plus tips and member-only offers · unsubscribe anytime", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = marketing, onCheckedChange = { changeMarketing(it) })
                }
                Row {
                    TextButton(onClick = { logout() }) { Text("Sign out") }
                    TextButton(onClick = { confirmDelete = true }) { Text("Delete account", color = MaterialTheme.colorScheme.error) }
                }
                HorizontalDivider()
                if (Ads.privacyOptionsRequired(this@MainActivity)) {
                    HorizontalDivider()
                    TextButton(onClick = { Ads.showPrivacyOptions(this@MainActivity) }) { Text("Ad privacy choices") }
                }
                OutlinedButton(onClick = { rateUs() }) { Text("⭐ Rate us on Google Play") }
                Row {
                    TextButton(onClick = { openUrl(PRIVACY_URL) }) { Text("Privacy policy") }
                    TextButton(onClick = { openUrl(TERMS_URL) }) { Text("Terms") }
                }
                HorizontalDivider()
                Text("Start fresh", fontWeight = FontWeight.SemiBold)
                OutlinedButton(onClick = { confirmReset = true }) { Text("Reset streak & badges") }

                HorizontalDivider()
                Text(
                    "Will-O-Wisp ${BuildConfig.VERSION_NAME} · made by JIYAA",
                    style = MaterialTheme.typography.labelSmall
                )
                if (BuildConfig.DEBUG) {
                    HorizontalDivider()
                    Text("Developer (debug builds only)", fontWeight = FontWeight.SemiBold)
                    OutlinedButton(onClick = {
                        val on = !pro
                        Store.setPro(this@MainActivity, on, "debug")
                        HabitWidget.updateAll(this@MainActivity)
                        pro = on
                        appTheme = Themes.current(this@MainActivity)
                        float(if (on) "Pro ON (test)" else "Pro OFF (test)")
                    }) { Text(if (pro) "Turn Pro off (test)" else "Turn Pro on (test)") }
                }
            }
        }
        if (confirmReset) {
            AlertDialog(
                onDismissRequest = { confirmReset = false },
                title = { Text("Reset streak & badges?") },
                text = { Text("This clears your wake-up history, streak freezes and alertness scores. Badges start again from 🌱 Wisp Awakened. Tags and alarm settings are kept.") },
                confirmButton = {
                    TextButton(onClick = {
                        Habit.reset(this@MainActivity)
                        confirmReset = false
                        resumeTick++
                        float("Fresh start ✨")
                    }) { Text("Reset") }
                },
                dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
            )
        }
    }

    @Composable
    private fun ThemeCard() {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🎨 Theme", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Themes.ALL.forEach { t ->
                        val label = "${t.emoji} ${t.name}" + if (t.pro && !pro) " ✦" else ""
                        val pick: () -> Unit = {
                            if (t.pro && !pro) {
                                showPro = true
                            } else {
                                Store.putStr(this@MainActivity, "theme", t.id)
                                appTheme = t
                            }
                        }
                        if (t.id == appTheme.id) Button(onClick = pick) { Text(label) }
                        else OutlinedButton(onClick = pick) { Text(label) }
                    }
                }
                Text("Changes the app, ring screen and wisp colours. ✦ = Pro", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    @Composable
    private fun AlertnessCard() {
        val tick = resumeTick
        val ctx = this@MainActivity
        val game = Alertness.todaysGame()
        val today = Alertness.today(ctx)
        val avg = Alertness.weekAverage(ctx)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("🧠 Morning alertness" + (if (tick < 0) "" else ""), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (today != null) {
                    Text("Today: $today % · ${Alertness.label(today)}")
                } else {
                    Text("Today's game: ${game.emoji} ${game.title}", style = MaterialTheme.typography.bodyMedium)
                }
                avg?.let { Text("7-day average: $it %", style = MaterialTheme.typography.bodySmall) }
                OutlinedButton(onClick = { startActivity(Intent(ctx, GameActivity::class.java).putExtra("fromMain", true)) }) {
                    Text(if (today == null) "Play today's game" else "Play again (practice)")
                }
            }
        }
    }

    @Composable
    private fun HabitCard() {
        val tick = resumeTick
        val grid = Habit.grid(this@MainActivity)
        val done = MaterialTheme.colorScheme.primary
        val missed = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.16f)
        val future = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Last 8 weeks" + (if (tick < 0) "" else ""), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf("S", "M", "T", "W", "T", "F", "S").forEach { d ->
                            Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
                                Text(d, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    grid.forEach { week ->
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            week.forEach { v ->
                                Box(
                                    Modifier.size(22.dp).clip(RoundedCornerShape(5.dp)).background(
                                        when (v) {
                                            1 -> done
                                            2 -> Color(0xFF9FD8F5)
                                            0 -> missed
                                            else -> future
                                        }
                                    )
                                )
                            }
                        }
                    }
                }
                Text(
                    "Filled = full tag cycle completed · Ice blue = streak freeze. Plain alarms and test runs don't count.",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "Tip: long-press your home screen → Widgets → Will-O-Wisp to add this as a widget.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    @Composable
    private fun DaysRow(days: Set<Int>, onChange: (Set<Int>) -> Unit) {
        val labels = listOf("S", "M", "T", "W", "T", "F", "S")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (i in 0 until 7) {
                val d = i + 1   // Calendar.SUNDAY = 1
                val on = d in days
                OutlinedButton(
                    onClick = { onChange(if (on) days - d else days + d) },
                    colors = if (on) ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors(),
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.weight(1f).height(40.dp)
                ) { Text(labels[i]) }
            }
        }
    }

    @Composable
    private fun Choice(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, modifier = Modifier.width(56.dp))
            options.forEachIndexed { i, o ->
                if (i == selected) Button(onClick = { }) { Text(o) }
                else OutlinedButton(onClick = { onSelect(i) }) { Text(o) }
            }
        }
    }

    @Composable
    private fun SetupCard() {
        val tick = resumeTick   // re-check whenever the app comes back to the foreground
        val todo = mutableListOf<Pair<String, () -> Unit>>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) todo += "Allow notifications" to { askNotifications() }
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
            todo += "Allow full-screen alarm" to {
                openSettings(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            }
        if (Build.VERSION.SDK_INT in 31..32 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms())
            todo += "Allow exact alarms" to {
                openSettings(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            }
        if (!getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName))
            todo += "Battery: set Will-O-Wisp to \"Don't optimise\" / \"Unrestricted\"" to {
                openSettings(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        if (nfc == null) {
            todo += "This phone has no NFC" to { }
        } else if (nfc?.isEnabled == false) {
            todo += "Turn on NFC" to { openSettings(Intent(Settings.ACTION_NFC_SETTINGS)) }
        }

        if (todo.isNotEmpty() && tick >= 0) {
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Setup needed for reliable alarms", fontWeight = FontWeight.Bold)
                    todo.forEach { (label, action) -> TextButton(onClick = action) { Text("→ $label") } }
                }
            }
        }
    }

    @Composable
    private fun TagsTab() {
        var renaming by remember { mutableStateOf<TagInfo?>(null) }
        var addingSet by remember { mutableStateOf(false) }
        var deleting by remember { mutableStateOf<TagInfo?>(null) }
        Column(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                sets.forEach { set ->
                    if (set == currentSet) Button(onClick = { }) { Text(set) }
                    else OutlinedButton(onClick = { currentSet = set; purpose = Purpose.NONE }) { Text(set) }
                }
                TextButton(onClick = { addingSet = true }) { Text("+ Set") }
            }
            val inSet = tags.filter { it.set == currentSet }
            Text(
                "$currentSet: ${inSet.size} / ${if (pro) Store.MAX_TAGS else Store.FREE_TAGS}" + (if (pro) "  ✦ Pro" else "  (free, all sets)"),
                fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
            Text(
                "Each alarm uses one set (e.g. Home or Travel). This list is the fixed order; Random shuffles it.",
                style = MaterialTheme.typography.bodySmall
            )
            AffiliateCard()
            if (purpose == Purpose.REGISTER) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Hold an NFC tag against the back of the phone…", fontWeight = FontWeight.SemiBold)
                        if (scanMsg.isNotEmpty()) Text(scanMsg)
                        TextButton(onClick = { purpose = Purpose.NONE; scanMsg = "" }) { Text("Cancel") }
                    }
                }
            } else {
                Button(
                    onClick = { scanMsg = ""; purpose = Purpose.REGISTER },
                    enabled = tags.count { it.set == currentSet } < Store.MAX_TAGS,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("+ Register a tag") }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val inSet = tags.filter { it.set == currentSet }
                itemsIndexed(inSet, key = { _, t -> t.uid }) { i, t ->
                    Card(Modifier.fillMaxWidth().alpha(if (t.enabled) 1f else 0.55f)) {
                        Column(Modifier.padding(start = 14.dp, end = 10.dp, top = 10.dp, bottom = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${i + 1}. ${t.name}", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                                    Text(
                                        if (t.enabled) t.uid else "Paused — the alarm skips this tag",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Switch(checked = t.enabled, onCheckedChange = { on ->
                                    if (!on && isLastArmedTag(t)) {
                                        float("Keep at least one tag on while the alarm is armed")
                                    } else {
                                        saveTags(tags.map { if (it.uid == t.uid) it.copy(enabled = on) else it })
                                    }
                                })
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(top = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TagBtn("▲", i > 0) { swapTags(t.uid, inSet[i - 1].uid) }
                                TagBtn("▼", i < inSet.size - 1) { swapTags(t.uid, inSet[i + 1].uid) }
                                Spacer(Modifier.weight(1f))
                                TagBtn("✎", true) { renaming = t }
                                TagBtn("🗑", true) { deleting = t }
                            }
                        }
                    }
                }
            }
        }
        if (addingSet) {
            NameDialog("New tag set", "Office", onDismiss = { addingSet = false }) { n ->
                if (n !in sets) {
                    Store.saveSets(this@MainActivity, sets + n)
                    reload()
                }
                currentSet = n
                addingSet = false
            }
        }
        val d = deleting
        if (d != null) {
            AlertDialog(
                onDismissRequest = { deleting = null },
                title = { Text("Delete \"${d.name}\"?") },
                text = { Text("The alarm will stop asking for this tag. To use it again you'll need to register it again. Tip: use the switch to pause a tag instead.") },
                confirmButton = {
                    TextButton(onClick = {
                        if (isLastArmedTag(d)) {
                            float("Keep at least one tag while the alarm is armed")
                        } else {
                            saveTags(tags.filter { it.uid != d.uid })
                        }
                        deleting = null
                    }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
            )
        }
        val r = renaming
        if (r != null) {
            NameDialog("Rename tag", r.name, onDismiss = { renaming = null }) { n ->
                saveTags(tags.map { if (it.uid == r.uid) it.copy(name = n) else it })
                renaming = null
            }
        }
    }

    @Composable
    private fun TagBtn(label: String, enabled: Boolean, onClick: () -> Unit) {
        FilledTonalIconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(46.dp)) {
            Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }

    private fun contactUs() {
        val body = "\n\n---\nApp: Will-O-Wisp ${BuildConfig.VERSION_NAME}\n" +
            "Phone: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})"
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(SUPPORT_EMAIL))
            .putExtra(Intent.EXTRA_SUBJECT, "Will-O-Wisp help")
            .putExtra(Intent.EXTRA_TEXT, body)
        try { startActivity(i) } catch (e: Exception) { float("No email app found — write to $SUPPORT_EMAIL") }
    }

    @Composable
    private fun HelpTab() {
        val faqs = listOf(
            "What is an NFC tag?" to "An NFC tag is a thin sticker, about the size of a coin, with a tiny chip and antenna inside. It has no battery and never needs charging. When you hold your phone close to it (about 1–3 cm), the phone powers it for a split second and reads its unique code — the same tap technology as contactless cards and metro cards. Will-O-Wisp simply remembers each sticker's code, so the alarm knows which one you tapped. Nothing is written to the sticker and no internet is needed. They come in packs and cost very little each.",
            "My tag doesn't read" to "Turn NFC on and unlock your phone. Find your phone's NFC spot (usually behind the camera or in the middle of the back) and hold the tag there for a second. Metal surfaces and thick or metal cases block NFC — move the tag or take the case off.",
            "The alarm didn't ring" to "The alarm switches itself off after every morning, so switch it on each night (the bedtime reminder helps). Also set battery to \"Unrestricted\" / \"Don't optimise\", allow notifications and full-screen alerts (see the setup card on the Alarms tab), and never force-stop the app.",
            "I'm travelling" to "Keep a second set of tags in your bag and pick the Travel set for that night, choose \"No tags (plain alarm)\", or simply leave the alarm off.",
            "A tag is lost or damaged" to "Use the switch next to the tag to pause it — the alarm skips paused tags. Or delete it and register a new sticker.",
            "What if I switch the phone off?" to "A phone that's off can't ring. Many phones can require your PIN to power off — look for \"Lock power menu\" or \"Require password to turn off\" in your phone's security settings.",
            "Pro, trial and billing" to "Pro is a yearly subscription with a free trial, sold through Google Play. Manage or cancel it in Play Store → Payments & subscriptions. On a new phone, open Pro and tap Restore.",
            "Ads" to "The free version shows a small banner on the main screen and, at most once a day, an ad after the alertness game. There are never ads on the alarm or wake-up screens. Pro removes all ads."
        )
        var open by remember { mutableIntStateOf(-1) }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    Modifier.fillMaxWidth().clickable { showGuide = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🗺️", fontSize = 34.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Setup guide", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Where to put your tags and how the alarm works, step by step.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Why 5 tags?", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        WhyFive()
                    }
                }
            }
            item { Text("Troubleshooting", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 6.dp)) }
            itemsIndexed(faqs) { i, (q, a) ->
                Card(Modifier.fillMaxWidth().clickable { open = if (open == i) -1 else i }) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(q, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Text(if (open == i) "–" else "+", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        if (open == i) Text(a, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Contact us", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Questions, ideas or something not working? We read every message.", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { contactUs() }) { Text("✉️  Email $SUPPORT_EMAIL") }
                        OutlinedButton(onClick = { rateUs() }) { Text("⭐  Rate Will-O-Wisp on Google Play") }
                        TextButton(onClick = { openUrl(BuildConfig.SITE_URL) }) { Text("Visit willowispalarm.com") }
                    }
                }
            }
        }
    }

    @Composable
    private fun WhyFive() {
        listOf(
            "🚶  About 2–3 minutes of walking — enough to wake your body, not a chore.",
            "🚪  Spread over different rooms, so you actually leave the bedroom.",
            "🛡️  Hard to cheat — five stickers can't all sit within reach of your bed.",
            "🔁  A spare built in — pause a damaged tag and you still have four.",
            "⚖️  The sweet spot — two is too easy, ten gets annoying on rushed mornings."
        ).forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
    }

    /** Small illustrated floor plan: bed → bathroom → kitchen → door, joined by a glowing trail. */
    @Composable
    private fun TrailGraphic() {
        val tm = rememberTextMeasurer()
        val line = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)
        val wisp = Color(0xFF56CCF2)
        val labelStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 11.sp)
        Canvas(Modifier.fillMaxWidth().height(170.dp)) {
            val w = size.width
            val h = size.height
            val rooms = listOf(
                Offset(0.02f * w, 0.55f * h) to Size(0.26f * w, 0.42f * h),
                Offset(0.26f * w, 0.28f * h) to Size(0.24f * w, 0.34f * h),
                Offset(0.52f * w, 0.04f * h) to Size(0.26f * w, 0.40f * h),
                Offset(0.76f * w, 0.50f * h) to Size(0.22f * w, 0.42f * h)
            )
            rooms.forEach { (o, sz) ->
                drawRoundRect(line, o, sz, CornerRadius(18f, 18f), style = Stroke(width = 3f))
            }
            val pts = listOf(
                Offset(0.12f * w, 0.76f * h), Offset(0.38f * w, 0.44f * h),
                Offset(0.65f * w, 0.24f * h), Offset(0.87f * w, 0.70f * h)
            )
            val path = Path().apply {
                moveTo(pts[0].x, pts[0].y)
                cubicTo(0.25f * w, 0.76f * h, 0.26f * w, 0.46f * h, pts[1].x, pts[1].y)
                cubicTo(0.50f * w, 0.42f * h, 0.55f * w, 0.20f * h, pts[2].x, pts[2].y)
                cubicTo(0.78f * w, 0.28f * h, 0.80f * w, 0.66f * h, pts[3].x, pts[3].y)
            }
            drawPath(path, wisp, style = Stroke(width = 5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 18f)), cap = androidx.compose.ui.graphics.StrokeCap.Round))
            drawRoundRect(Color(0xFF2F80ED).copy(alpha = 0.6f), Offset(pts[0].x - 22f, pts[0].y - 12f), Size(44f, 24f), CornerRadius(8f, 8f))
            pts.drop(1).forEachIndexed { i, p ->
                drawCircle(wisp.copy(alpha = 0.25f), radius = 26f, center = p)
                drawCircle(wisp, radius = 12f, center = p, style = if (i == 2) androidx.compose.ui.graphics.drawscope.Fill else Stroke(width = 5f))
            }
            listOf("Bed" to pts[0], "Bathroom" to pts[1], "Kitchen" to pts[2], "Front door" to pts[3]).forEach { (t, p) ->
                try {
                    val layout = tm.measure(t, labelStyle)
                    val x = (p.x - layout.size.width / 2f).coerceIn(0f, (w - layout.size.width).coerceAtLeast(0f))
                    val y = (p.y + 22f).coerceAtMost((h - layout.size.height).coerceAtLeast(0f))
                    drawText(layout, topLeft = Offset(x, y))
                } catch (_: Exception) { }
            }
        }
    }

    /** Full-screen setup infographic. */
    @Composable
    private fun SetupGuide() {
        BackHandler { showGuide = false }
        val steps = listOf(
            Triple("🏷️", "Get 5 NFC stickers", "NTAG213, 215 or 216 — or almost any NFC sticker — works. The Tags tab links to recommended ones for your country."),
            Triple("🗺️", "Plan your trail", "Choose spots in different rooms — the bathroom door, a kitchen cupboard, your wooden front door. Not on metal: fridges, kettles and steel frames block NFC. Put the first tag farthest from your bed, and none within reach of it."),
            Triple("📱", "Find your phone's NFC spot", "It's usually behind the camera or in the middle of the back. Slide a tag slowly across until the phone reacts."),
            Triple("✍️", "Register and name each tag", "Tags tab → + Register a tag → hold the sticker to your phone → give it a name like Kitchen or Door."),
            Triple("⚙️", "Choose how tough", "Normal: each tap gives 20 seconds of quiet. Crazy: it rings until the last tag. Pick a fixed or random order."),
            Triple("🌙", "Arm it every night", "The alarm switches itself off after each morning. Switch it on at bedtime — the reminder will nudge you."),
            Triple("🧪", "Test once", "Tap Test now on the alarm and walk the whole trail, so you know every tag reads."),
            Triple("🔥", "Walk, tap, wake up", "When it rings, follow the wisp from tag to tag. Last tap: Good morning — and a new badge.")
        )
        val accent = MaterialTheme.colorScheme.primary
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Set up your trail", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { showGuide = false }) { Text("✕", fontSize = 22.sp) }
                    }
                    Text("Ten minutes tonight, better mornings from tomorrow.", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    TrailGraphic()
                    Spacer(Modifier.height(12.dp))
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("New to NFC? 📶", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("An NFC tag is a thin sticker, about the size of a coin, with a tiny chip and antenna inside. It has no battery and never needs charging. When you hold your phone close to it (about 1–3 cm), the phone powers it for a split second and reads its unique code — the same tap technology as contactless cards and metro cards. Will-O-Wisp simply remembers each sticker's code, so the alarm knows which one you tapped. Nothing is written to the sticker and no internet is needed. They come in packs and cost very little each.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
                itemsIndexed(steps) { i, (emoji, title, text) ->
                    Row(Modifier.fillMaxWidth()) {
                        // number + connecting line
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(44.dp)) {
                            Box(
                                Modifier.size(36.dp).clip(RoundedCornerShape(50)).background(accent),
                                contentAlignment = Alignment.Center
                            ) { Text("${i + 1}", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold) }
                            if (i < steps.size - 1) {
                                Box(Modifier.width(3.dp).height(78.dp).background(accent.copy(alpha = 0.35f)))
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f).padding(bottom = 14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(emoji, fontSize = 24.sp)
                                Spacer(Modifier.width(8.dp))
                                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                            Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Why 5 tags?", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            WhyFive()
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { showGuide = false }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Got it — let's go") }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    @Composable
    private fun SmallBtn(label: String, enabled: Boolean, onClick: () -> Unit) {
        TextButton(
            onClick = onClick, enabled = enabled,
            contentPadding = PaddingValues(0.dp),
            modifier = Modifier.size(40.dp)
        ) { Text(label, fontSize = 18.sp) }
    }

    @Composable
    private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
        var text by remember { mutableStateOf(initial) }
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(title) },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.take(24) }, singleLine = true,
                    label = { Text("Name (e.g. Kitchen)") }
                )
            },
            confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onSave(text.trim()) }) { Text("Save") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
        )
    }
}
