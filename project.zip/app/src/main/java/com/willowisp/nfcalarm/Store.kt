package com.willowisp.nfcalarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** NFC tag UID as "04:A2:…" — works with any brand of tag. */
fun uidHex(id: ByteArray): String = id.joinToString(":") { "%02X".format(it) }

data class TagInfo(
    val uid: String,
    val name: String,
    val genuine: Boolean = false,
    val set: String = Store.DEFAULT_SET,         // e.g. "Home", "Travel"
    val enabled: Boolean = true                  // paused tags are skipped when the alarm rings
)

data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val days: Set<Int>,      // Calendar.SUNDAY(1)..SATURDAY(7); empty = one-time alarm
    val enabled: Boolean,
    val crazy: Boolean,      // false = Normal mode, true = Crazy mode
    val random: Boolean,     // false = fixed order, true = random order
    val tagSet: String = Store.DEFAULT_SET,
    val noTags: Boolean = false,      // plain alarm with a Stop button
    val soundUri: String = "",        // "" = phone's default alarm sound
    val soundName: String = "Will-O-Wisp chime",
    val gradual: Boolean = false,     // fade in over 60 s
    val voice: Boolean = true,        // speak the next tag's name
    val sunrise: Boolean = false      // screen + flashlight brighten 10 min before
)

object Store {
    const val MAX_TAGS = 10           // per tag set (Pro)
    const val FREE_TAGS = 2           // total, free version
    const val DEFAULT_SET = "Home"

    private fun prefs(c: Context) = c.getSharedPreferences("wisp", Context.MODE_PRIVATE)

    fun getStr(c: Context, key: String): String = prefs(c).getString(key, "") ?: ""
    fun putStr(c: Context, key: String, value: String) { prefs(c).edit().putString(key, value).apply() }

    /** Pro = bought on Google Play, toggled on in a debug build, or unlocked until tomorrow noon by a rewarded ad. */
    fun isPro(c: Context): Boolean = hasRealPro(c) || System.currentTimeMillis() < proUntil(c)
    fun hasRealPro(c: Context): Boolean = prefs(c).getBoolean("pro", false)
    fun proSource(c: Context): String = prefs(c).getString("proSource", "") ?: ""
    fun setPro(c: Context, on: Boolean = true, source: String = "play") {
        prefs(c).edit().putBoolean("pro", on).putString("proSource", if (on) source else "").apply()
    }
    fun proUntil(c: Context): Long = prefs(c).getLong("proUntil", 0L)

    // ---------- Pro by rewarded ad: 18 hours, once a week ----------
    const val AD_PRO_HOURS = 18
    const val AD_PRO_EVERY_DAYS = 7
    fun adProLastAt(c: Context): Long = prefs(c).getLong("adProLastAt", 0L)
    fun adProAvailableAt(c: Context): Long = adProLastAt(c) + AD_PRO_EVERY_DAYS * 24L * 60 * 60 * 1000
    fun canUseAdPro(c: Context): Boolean = System.currentTimeMillis() >= adProAvailableAt(c)
    fun grantAdPro(c: Context) {
        val now = System.currentTimeMillis()
        prefs(c).edit().putLong("adProLastAt", now)
            .putLong("proUntil", now + AD_PRO_HOURS * 60L * 60 * 1000).apply()
    }
    fun setProUntil(c: Context, t: Long) { prefs(c).edit().putLong("proUntil", t).apply() }

    // ---------- first-run + bedtime ----------
    fun onboarded(c: Context) = prefs(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context) { prefs(c).edit().putBoolean("onboarded", true).apply() }

    fun bedHour(c: Context) = prefs(c).getInt("bedHour", 22)
    fun bedMinute(c: Context) = prefs(c).getInt("bedMinute", 30)
    fun bedLeadMin(c: Context) = prefs(c).getInt("bedLead", 60)          // reminder 60 or 120 min before
    fun bedOn(c: Context) = prefs(c).getBoolean("bedOn", true)
    fun saveBedtime(c: Context, hour: Int, minute: Int, leadMin: Int, on: Boolean) {
        prefs(c).edit().putInt("bedHour", hour).putInt("bedMinute", minute)
            .putInt("bedLead", leadMin).putBoolean("bedOn", on).apply()
    }

    // ---------- tags ----------
    fun tags(c: Context): List<TagInfo> {
        val arr = JSONArray(prefs(c).getString("tags", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            TagInfo(
                o.getString("uid"), o.getString("name"),
                o.optBoolean("genuine", false), o.optString("set", DEFAULT_SET),
                o.optBoolean("enabled", true)
            )
        }
    }

    fun saveTags(c: Context, list: List<TagInfo>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("uid", it.uid).put("name", it.name).put("genuine", it.genuine).put("set", it.set).put("enabled", it.enabled))
        }
        prefs(c).edit().putString("tags", arr.toString()).apply()
    }

    // ---------- tag sets ----------
    fun sets(c: Context): List<String> {
        val arr = JSONArray(prefs(c).getString("sets", "[\"Home\",\"Travel\"]"))
        val list = (0 until arr.length()).map { arr.getString(it) }.toMutableList()
        tags(c).map { it.set }.forEach { if (it !in list) list.add(it) }
        return list
    }

    fun saveSets(c: Context, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs(c).edit().putString("sets", arr.toString()).apply()
    }

    // ---------- alarms ----------
    fun alarms(c: Context): List<AlarmItem> {
        val arr = JSONArray(prefs(c).getString("alarms", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val d = o.getJSONArray("days")
            AlarmItem(
                id = o.getInt("id"),
                hour = o.getInt("hour"),
                minute = o.getInt("minute"),
                days = (0 until d.length()).map { i -> d.getInt(i) }.toSet(),
                enabled = o.getBoolean("enabled"),
                crazy = o.getBoolean("crazy"),
                random = o.getBoolean("random"),
                tagSet = o.optString("tagSet", DEFAULT_SET),
                noTags = o.optBoolean("noTags", false),
                soundUri = o.optString("soundUri", ""),
                soundName = o.optString("soundName", "Will-O-Wisp chime").let { if (it == "Default alarm") "Will-O-Wisp chime" else it },
                gradual = o.optBoolean("gradual", false),
                voice = o.optBoolean("voice", true),
                sunrise = o.optBoolean("sunrise", false)
            )
        }
    }

    private fun saveAlarms(c: Context, list: List<AlarmItem>) {
        val arr = JSONArray()
        list.forEach { a ->
            val d = JSONArray()
            a.days.sorted().forEach { d.put(it) }
            arr.put(
                JSONObject().put("id", a.id).put("hour", a.hour).put("minute", a.minute)
                    .put("days", d).put("enabled", a.enabled).put("crazy", a.crazy).put("random", a.random)
                    .put("tagSet", a.tagSet).put("noTags", a.noTags)
                    .put("soundUri", a.soundUri).put("soundName", a.soundName).put("gradual", a.gradual)
                    .put("voice", a.voice).put("sunrise", a.sunrise)
            )
        }
        prefs(c).edit().putString("alarms", arr.toString()).commit()
    }

    fun upsertAlarm(c: Context, a: AlarmItem) {
        val list = alarms(c).toMutableList()
        val i = list.indexOfFirst { it.id == a.id }
        if (i >= 0) list[i] = a else list.add(a)
        saveAlarms(c, list.sortedBy { it.hour * 60 + it.minute })
    }

    fun deleteAlarm(c: Context, id: Int) = saveAlarms(c, alarms(c).filter { it.id != id })

    fun nextAlarmId(c: Context): Int = (alarms(c).maxOfOrNull { it.id } ?: 0) + 1

    // ---------- wake-up history (dates "yyyy-MM-dd" with a full-cycle disarm) ----------
    fun history(c: Context): Set<String> {
        val arr = JSONArray(prefs(c).getString("history", "[]"))
        return (0 until arr.length()).map { arr.getString(it) }.toSet()
    }

    // ---------- "phone switched off during the alarm" detection ----------
    /** Set while a real (non-test) alarm is ringing; cleared when it finishes. Still set after a reboot = escape. */
    fun ringingSince(c: Context): Long = prefs(c).getLong("ringingSince", 0L)
    fun setRingingSince(c: Context, t: Long) { prefs(c).edit().putLong("ringingSince", t).commit() }

    /** Days with a switched-off-alarm penalty: the streak is broken and freezes can't cover them. */
    fun penalties(c: Context): Set<String> {
        val arr = JSONArray(prefs(c).getString("penalties", "[]"))
        return (0 until arr.length()).map { arr.getString(it) }.toSet()
    }
    fun addPenalty(c: Context, day: String) {
        val arr = JSONArray()
        (penalties(c) + day).sorted().forEach { arr.put(it) }
        prefs(c).edit().putString("penalties", arr.toString()).commit()
    }

    // ---------- review prompt ----------
    fun reviewDone(c: Context) = prefs(c).getBoolean("reviewDone", false)
    fun setReviewDone(c: Context) { prefs(c).edit().putBoolean("reviewDone", true).apply() }
    fun reviewLastAsk(c: Context) = prefs(c).getLong("reviewLastAsk", 0L)
    fun reviewAsks(c: Context) = prefs(c).getInt("reviewAsks", 0)
    fun noteReviewAsk(c: Context) {
        prefs(c).edit().putLong("reviewLastAsk", System.currentTimeMillis()).putInt("reviewAsks", reviewAsks(c) + 1).apply()
    }

    /** Days covered by a streak freeze ("yyyy-MM-dd"). They keep the streak alive but don't count as wake-ups. */
    fun frozen(c: Context): Set<String> {
        val arr = JSONArray(prefs(c).getString("frozen", "[]"))
        return (0 until arr.length()).map { arr.getString(it) }.toSet()
    }

    fun saveFrozen(c: Context, days: Set<String>) {
        val arr = JSONArray()
        days.sorted().forEach { arr.put(it) }
        prefs(c).edit().putString("frozen", arr.toString()).commit()
    }

    fun saveHistory(c: Context, days: Set<String>) {
        val arr = JSONArray()
        days.sorted().forEach { arr.put(it) }
        prefs(c).edit().putString("history", arr.toString()).commit()
    }
}
