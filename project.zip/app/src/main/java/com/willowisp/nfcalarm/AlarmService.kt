package com.willowisp.nfcalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class RingState(
    val active: Boolean = false,
    val sequence: List<TagInfo> = emptyList(),
    val index: Int = 0,
    val ringing: Boolean = false,
    val crazy: Boolean = false,
    val secondsLeft: Int? = null,
    val message: String = "",
    val noTags: Boolean = false,      // plain alarm: Stop button, no tags needed
    val setName: String = "",
    val won: Boolean = false,         // set when the last tag was tapped (ring screen celebrates)
    val test: Boolean = false         // started with "Test now": never counts toward streak/badges
)

class AlarmService : Service() {

    companion object {
        private val _state = MutableStateFlow(RingState())
        val state: StateFlow<RingState> = _state
        private var instance: AlarmService? = null
        private const val CHANNEL = "wisp_alarm"
        private const val NOTIF_ID = 42
        const val GAP_MS = 20_000L   // Normal mode: time allowed to reach the next tag

        fun onTag(uid: String) { instance?.handleTag(uid) }
        /** Plain alarm / no tags in the set: simple stop (not counted as a win). */
        fun stopNoTags() { instance?.finishAlarm(win = false) }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var gapDeadline = 0L
    private var savedVolume = -1
    private var wakeLock: PowerManager.WakeLock? = null
    private var soundUri: String = ""
    private var gradual = false
    private var proActive = false
    private var startedAt = 0L
    private var randomOrder = false
    private var voice = true
    private var isTest = false
    private val ringPattern: VibrationEffect = VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0)
    private var level = 1f                 // current player volume (0..1), used by fade-in
    private var fadeStart = 0L
    private val FADE_MS = 60_000L

    private val alarmAttrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator
        else getSystemService(Vibrator::class.java)
    }
    private val audio: AudioManager by lazy { getSystemService(AudioManager::class.java) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()
        if (_state.value.active) return START_NOT_STICKY   // already ringing
        instance = this

        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wisp:alarm")
            .apply { acquire(60 * 60 * 1000L) }

        val id = intent?.getIntExtra("id", -1) ?: -1
        isTest = intent?.getBooleanExtra("test", false) ?: false
        if (!isTest) Store.setRingingSince(this, System.currentTimeMillis())
        val alarm = Store.alarms(this).firstOrNull { it.id == id }
        val pro = Store.isPro(this)
        val noTags = alarm?.noTags == true
        val setName = alarm?.tagSet ?: Store.DEFAULT_SET
        val all = Store.tags(this).filter { it.enabled }   // paused tags are skipped
        proActive = pro
        randomOrder = pro && alarm?.random == true
        val inSet = all.filter { it.set == setName }
        val tags = if (noTags) emptyList() else if (pro) inSet else inSet.take(Store.FREE_TAGS)
        val seq = if (randomOrder) tags.shuffled() else tags
        startedAt = System.currentTimeMillis()
        Analytics.log(this, "alarm_rang", "set" to setName, "tags" to seq.size,
            "mode" to (if (pro && alarm?.crazy == true) "crazy" else "normal"),
            "random" to randomOrder, "no_tags" to noTags, "test" to isTest)
        Funnel.once(this, "first_alarm_started", "test" to isTest, "tags" to seq.size)
        Funnel.checkReturn(this)
        soundUri = alarm?.soundUri ?: ""
        gradual = alarm?.gradual == true
        voice = alarm?.voice ?: true
        _state.value = RingState(
            active = true, sequence = seq, index = 0, ringing = false,
            crazy = pro && (alarm?.crazy ?: false),
            noTags = noTags, setName = setName, test = isTest,
            message = when {
                noTags -> ""
                seq.isEmpty() -> "No tags in \"$setName\" — register tags in the app"
                else -> ""
            }
        )

        savedVolume = try { audio.getStreamVolume(AudioManager.STREAM_ALARM) } catch (e: Exception) { -1 }
        startRinging()
        handler.post(volumeGuard)

        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setAudioAttributes(alarmAttrs)
                announceNext()
            }
        }
        try {
            startActivity(Intent(this, RingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }
        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, RingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Will-O-Wisp alarm")
            .setContentText("Walk to your tags to stop the alarm")
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildPlayer(): MediaPlayer? {
        val chosen: Uri? = if (soundUri.isNotBlank()) Uri.parse(soundUri) else null
        val chime: Uri = Uri.parse("android.resource://$packageName/${R.raw.wisp_chime}")
        val candidates: List<Uri?> = listOf(
            chosen,
            chime,                                         // default: the Will-O-Wisp chime
            RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        )
        for (uri in candidates) {
            if (uri == null) continue
            try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(alarmAttrs)
                mp.setDataSource(this, uri)
                mp.isLooping = true
                mp.prepare()
                return mp
            } catch (e: Exception) { }
        }
        return null
    }

    private fun startRinging() {
        val first = player == null
        if (first) player = buildPlayer()
        if (first && gradual) {
            level = 0.05f
            fadeStart = SystemClock.elapsedRealtime()
            handler.post(fadeIn)
        } else {
            handler.removeCallbacks(fadeIn)
            level = 1f
        }
        player?.setVolume(level, level)
        try { if (player?.isPlaying != true) player?.start() } catch (e: Exception) { }
        vibrator.vibrate(ringPattern, alarmAttrs)
        _state.update { it.copy(ringing = true, secondsLeft = null) }
        forceMaxVolume()
    }

    private fun pauseRinging() {
        try { if (player?.isPlaying == true) player?.pause() } catch (e: Exception) { }
        vibrator.cancel()
        _state.update { it.copy(ringing = false) }
    }

    private fun forceMaxVolume() {
        try {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (audio.getStreamVolume(AudioManager.STREAM_ALARM) < max) {
                audio.setStreamVolume(AudioManager.STREAM_ALARM, max, 0)
            }
        } catch (e: Exception) { }
    }

    // Anti-cheat: if the user turns the volume down while ringing, push it back up
    private val volumeGuard: Runnable = object : Runnable {
        override fun run() {
            if (_state.value.ringing) forceMaxVolume()
            handler.postDelayed(this, 1500)
        }
    }

    // Normal mode: countdown to reach the next tag
    private val gapTick: Runnable = object : Runnable {
        override fun run() {
            val left = gapDeadline - SystemClock.elapsedRealtime()
            if (left <= 0) {
                _state.update { it.copy(message = "Too slow! The alarm is back.") }
                startRinging()
                announceNext()
            } else {
                _state.update { it.copy(secondsLeft = ((left + 999) / 1000).toInt()) }
                handler.postDelayed(this, 250)
            }
        }
    }

    private var ducked = false
    private val restoreVolume = Runnable { ducked = false; player?.setVolume(level, level) }

    // Gradual volume: rises from 5% to 100% over 60 s
    private val fadeIn: Runnable = object : Runnable {
        override fun run() {
            val t = (SystemClock.elapsedRealtime() - fadeStart).toFloat() / FADE_MS
            level = (0.05f + 0.95f * t).coerceIn(0.05f, 1f)
            if (!ducked) player?.setVolume(level, level)
            if (level < 1f) handler.postDelayed(this, 1000)
        }
    }

    // Tap feedback: one firm buzz = correct tag, three short buzzes = wrong tag
    private val resumeRingVibe = Runnable {
        if (_state.value.ringing) vibrator.vibrate(ringPattern, alarmAttrs)
    }

    private fun tapBuzz(ok: Boolean) {
        val effect = if (ok) VibrationEffect.createOneShot(300, 255)
        else VibrationEffect.createWaveform(longArrayOf(0, 120, 90, 120, 90, 120), -1)
        vibrator.vibrate(effect, alarmAttrs)
        handler.removeCallbacks(resumeRingVibe)
        if (_state.value.ringing) handler.postDelayed(resumeRingVibe, 800)
    }

    private fun announceNext() {
        val s = _state.value
        if (!voice || !ttsReady || s.index >= s.sequence.size) return
        if (s.ringing) {   // duck the alarm briefly so the name is audible
            ducked = true
            player?.setVolume(0.15f * level, 0.15f * level)
            handler.removeCallbacks(restoreVolume)
            handler.postDelayed(restoreVolume, 2500)
        }
        tts?.speak("Next, ${s.sequence[s.index].name}", TextToSpeech.QUEUE_FLUSH, null, "next")
    }

    fun handleTag(uid: String) {
        val s = _state.value
        if (!s.active || s.sequence.isEmpty() || s.index >= s.sequence.size) return
        val expected = s.sequence[s.index]

        if (uid != expected.uid && s.sequence.none { it.uid == uid }) {
            // a tag from another set (e.g. Travel while Home was chosen): switch to the set you actually have
            val other = Store.tags(this).firstOrNull { it.uid == uid && it.enabled && it.set != s.setName }
            if (other != null && switchSet(other)) return
        }
        if (uid != expected.uid) {
            val known = s.sequence.firstOrNull { it.uid == uid }
            _state.update {
                it.copy(message = if (known != null) "That's ${known.name}. Go to ${expected.name}." else "Not one of your tags.")
            }
            tapBuzz(ok = false)
            return
        }

        val next = s.index + 1
        if (next >= s.sequence.size) {
            finishAlarm(win = true)
            return
        }
        _state.update { it.copy(index = next, message = "✓ ${expected.name}") }

        if (!s.crazy) {   // Normal mode: go quiet, start 20 s window for the next tag
            pauseRinging()
            tapBuzz(ok = true)
            gapDeadline = SystemClock.elapsedRealtime() + GAP_MS
            handler.removeCallbacks(gapTick)
            handler.post(gapTick)
        } else {
            tapBuzz(ok = true)
        }
        announceNext()
    }

    /** Rebuilds today's sequence from the tapped tag's set. Returns false if it can't be used. */
    private fun switchSet(tapped: TagInfo): Boolean {
        var list = Store.tags(this).filter { it.enabled && it.set == tapped.set }
        if (!proActive) list = list.take(Store.FREE_TAGS)
        if (list.none { it.uid == tapped.uid }) return false
        list = if (randomOrder) listOf(tapped) + list.filter { it.uid != tapped.uid }.shuffled() else list
        _state.update {
            it.copy(sequence = list, index = 0, setName = tapped.set, message = "Using your ${tapped.set} tags today")
        }
        if (list.first().uid == tapped.uid) {
            handleTag(tapped.uid)          // counts as the first correct tap
        } else {
            _state.update { it.copy(message = "Using your ${tapped.set} tags today — start with ${list.first().name}") }
            tapBuzz(ok = true)
            announceNext()
        }
        return true
    }

    fun finishAlarm(win: Boolean = false) {
        Store.setRingingSince(this, 0L)   // finished normally — not an escape
        val st = _state.value
        Analytics.log(this, if (win) "wake_completed" else "alarm_stopped",
            "tags" to st.sequence.size, "set" to st.setName, "mode" to (if (st.crazy) "crazy" else "normal"),
            "seconds" to ((System.currentTimeMillis() - startedAt) / 1000).toInt(), "test" to isTest)
        if (win) Funnel.once(this, "first_wisp_completed", "test" to isTest, "tags" to st.sequence.size)
        if (win && !isTest) {   // test runs never count toward the streak or badges
            try { Habit.recordWin(this) } catch (_: Exception) { }
        }
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (e: Exception) { }
        player?.release()
        player = null
        vibrator.cancel()
        if (win) {   // celebratory buzz on the last tag
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 150, 100, 150, 100, 500), -1), alarmAttrs)
        }
        if (savedVolume >= 0) {
            try { audio.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0) } catch (e: Exception) { }
        }
        tts?.shutdown()
        tts = null
        ttsReady = false
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        _state.value = RingState(won = win, test = isTest)
        instance = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (instance === this) finishAlarm()
        super.onDestroy()
    }
}
