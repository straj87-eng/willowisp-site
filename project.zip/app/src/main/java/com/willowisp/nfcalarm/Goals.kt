package com.willowisp.nfcalarm

import android.content.Context

/** "What gets you up?" — the user's reason to wake, used on the ring screen, the finale and bedtime reminders. */
data class Goal(
    val id: String,
    val emoji: String,
    val label: String,
    val ringLine: String,      // shown while the alarm rings
    val winLine: String,       // shown on the "Good morning" finale
    val bedtimeLine: String    // added to the bedtime reminder
)

object Goals {
    val ALL = listOf(
        Goal("workout", "🏋️", "My morning workout",
            "Your workout is waiting — get moving!",
            "You're up. Go crush that workout 💪",
            "Sleep now so tomorrow's workout actually happens."),
        Goal("family", "👨‍👩‍👧", "Time with my family",
            "Breakfast with your family beats ten more minutes in bed.",
            "Go enjoy the morning with your family ❤️",
            "An early night means a calm morning with your family."),
        Goal("kids", "⚽", "My kids' school & sports",
            "Don't miss their big moment — up you get!",
            "You'll be there for them today 🏆",
            "Rest up — they'll be looking for you in the crowd."),
        Goal("work", "💼", "Getting to work on time",
            "Beat the traffic, beat the stress.",
            "Unrushed and on time today ✅",
            "Lights out soon and tomorrow starts without the rush."),
        Goal("study", "📚", "Study & exam prep",
            "Your best study hours start now.",
            "Prime study time, unlocked 📖",
            "A good night's sleep makes tomorrow's revision stick."),
        Goal("calm", "🧘", "Prayer, yoga or quiet time",
            "Your quiet hour is waiting.",
            "Enjoy your calm start 🌅",
            "Sleep now and protect tomorrow's quiet hour."),
        Goal("me", "☕", "Me-time before the rush",
            "Your peaceful coffee is waiting.",
            "Enjoy the quiet before the world wakes ☕",
            "Turn in soon — your quiet morning is worth it.")
    )

    fun current(c: Context): Goal? = ALL.firstOrNull { it.id == Store.getStr(c, "goal") }
    fun set(c: Context, id: String) = Store.putStr(c, "goal", id)
}
