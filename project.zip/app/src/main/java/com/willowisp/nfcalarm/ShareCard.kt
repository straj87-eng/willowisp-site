package com.willowisp.nfcalarm

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/** Renders the latest badge as an Instagram-sized card and opens the share sheet. */
object ShareCard {

    fun share(activity: Activity, theme: WispTheme) {
        val b = Habit.latestBadge(activity) ?: return
        val bmp = render(activity, b, theme)
        val dir = File(activity.cacheDir, "share").apply { mkdirs() }
        val file = File(dir, "willowisp_badge.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.share", file)
        val streak = Habit.streak(activity)
        val text = "${b.emoji} I'm now a ${b.title} on Will-O-Wisp NFC Alarm" +
            (if (streak > 1) " — $streak-day streak!" else "!") + " ${b.caption}"
        val send = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_TEXT, text)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(send, "Share your badge"))
    }

    private fun centered(canvas: Canvas, text: String, y: Float, paint: Paint, w: Int) {
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(text, w / 2f, y, paint)
    }

    fun render(c: Context, b: Badge, t: WispTheme): Bitmap {
        val w = 1080
        val h = 1350
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bg = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h.toFloat(), t.surface.toArgb(), t.background.toArgb(), Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        val textColor = if (t.dark) 0xFFFFFFFF.toInt() else 0xFF3A1A0A.toInt()
        val accent = t.primary.toArgb()

        // medallion
        val medal = BitmapFactory.decodeResource(c.resources, R.drawable.badge_welcome)
        if (medal != null) {
            val mw = 620
            val mh = (medal.height * mw / medal.width.toFloat()).toInt()
            val left = (w - mw) / 2
            canvas.drawBitmap(medal, null, Rect(left, 90, left + mw, 90 + mh), Paint(Paint.FILTER_BITMAP_FLAG))
            // badge emoji bubble
            if (b.days > 0) {
                val cx = left + mw - 70f
                val cy = 150f
                canvas.drawCircle(cx, cy, 92f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() })
                val ep = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 110f; textAlign = Paint.Align.CENTER }
                canvas.drawText(b.emoji, cx, cy + 38f, ep)
            }
        }

        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = textColor; textSize = 46f }
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor; textSize = 82f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        centered(canvas, if (b.days > 0) "I'm now a" else "Badge unlocked", 800f, small, w)
        centered(canvas, b.title, 900f, big, w)

        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = textColor; textSize = 42f; alpha = 220 }
        val layout = StaticLayout.Builder.obtain(b.caption, 0, b.caption.length, tp, 900)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        canvas.save()
        canvas.translate((w - 900) / 2f, 950f)
        layout.draw(canvas)
        canvas.restore()

        val stats = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent; textSize = 50f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        centered(canvas, "🔥 ${Habit.streak(c)}-day streak  ·  ${Habit.total(c)} wake-ups", 1160f, stats, w)
        val foot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = textColor; textSize = 36f; alpha = 200 }
        centered(canvas, "Will-O-Wisp NFC Alarm  ·  Wake up. Walk. Win.", 1280f, foot, w)
        return bmp
    }
}
