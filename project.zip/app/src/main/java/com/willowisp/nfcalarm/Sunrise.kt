package com.willowisp.nfcalarm

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Sunrise mode: 10 minutes before the alarm the screen glows warmer and brighter; the flashlight joins at the end. */
object Sunrise {
    const val LEAD_MS = 10 * 60 * 1000L
    private const val NOTIF_ID = 78

    private fun operation(c: Context, id: Int): PendingIntent = PendingIntent.getBroadcast(
        c, 5000 + id, Intent(c, SunriseReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun cancel(c: Context, id: Int) {
        c.getSystemService(AlarmManager::class.java).cancel(operation(c, id))
    }

    fun schedule(c: Context, a: AlarmItem) {
        cancel(c, a.id)
        if (!a.enabled || !a.sunrise) return
        val t = AlarmScheduler.nextTrigger(a) - LEAD_MS
        if (t <= System.currentTimeMillis()) return
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, operation(c, a.id))
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, operation(c, a.id))
        }
    }

    fun start(c: Context, alarmAt: Long) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = "wisp_sunrise"
        if (nm.getNotificationChannel(ch) == null) {
            nm.createNotificationChannel(
                NotificationChannel(ch, "Sunrise mode", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(null, null); enableVibration(false)
                }
            )
        }
        val i = Intent(c, SunriseActivity::class.java)
            .putExtra("alarmAt", alarmAt)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(c, 6, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_menu_day)
            .setContentTitle("🌅 Sunrise")
            .setContentText("Your alarm rings soon")
            .setCategory(Notification.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        try { nm.notify(NOTIF_ID, n) } catch (_: SecurityException) { }
        try { c.startActivity(i) } catch (_: Exception) { }
    }

    fun clearNotification(c: Context) {
        c.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }
}

class SunriseReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val a = Store.alarms(c).firstOrNull { it.id == id } ?: return
        if (!a.enabled || !a.sunrise) return
        Sunrise.start(c, AlarmScheduler.nextTrigger(a))
    }
}

class SunriseActivity : ComponentActivity() {
    private var torchId: String? = null
    private var torchOn = false
    private var dimmable: Boolean? = null
    private var closing = false
    private var alarmAt = 0L
    private var progress by mutableFloatStateOf(0f)
    private val handler = Handler(Looper.getMainLooper())
    private var cpuLock: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        alarmAt = intent.getLongExtra("alarmAt", System.currentTimeMillis() + Sunrise.LEAD_MS)
        // keep the CPU awake for the whole sunrise so the light keeps rising even if the screen is switched off
        cpuLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wisp:sunrise")
            .apply { acquire(Sunrise.LEAD_MS + 3 * 60 * 1000L) }
        handler.post(tick)
        setComposeContent(androidx.compose.ui.graphics.Color.Black) { SunriseScreen() }
    }

    override fun onDestroy() {
        closing = true
        handler.removeCallbacks(tick)
        torch(0f)
        cpuLock?.let { if (it.isHeld) it.release() }
        Sunrise.clearNotification(this)
        super.onDestroy()
    }

    private fun close() {
        closing = true
        finish()
    }

    // runs every second, even while the screen is off
    private val tick: Runnable = object : Runnable {
        override fun run() {
            if (closing) return
            val now = System.currentTimeMillis()
            val start = alarmAt - Sunrise.LEAD_MS
            progress = ((now - start).toFloat() / Sunrise.LEAD_MS).coerceIn(0f, 1f)
            setBrightness(0.02f + 0.98f * progress)
            updateTorch(progress)
            if (AlarmService.state.value.active || now > alarmAt + 2 * 60 * 1000L) { close(); return }
            // if the lock button switched the screen off, bring the sunrise back
            if (!getSystemService(PowerManager::class.java).isInteractive) wakeScreen()
            handler.postDelayed(this, 1000)
        }
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        try {
            getSystemService(PowerManager::class.java).newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "wisp:sunrise-wake"
            ).acquire(3000)
        } catch (_: Exception) { }
    }

    private fun setBrightness(level: Float) {
        val lp = window.attributes
        lp.screenBrightness = level.coerceIn(0.01f, 1f)
        window.attributes = lp
    }

    /**
     * Phones with a dimmable flashlight (Android 13+, supported hardware): rises over the last 3 minutes.
     * Other phones only have one brightness, so the flashlight switches on for the final minute.
     */
    private fun updateTorch(p: Float) {
        if (dimmable == null) dimmable = isDimmable()
        val level = if (dimmable == true) {
            if (p > 0.7f) (p - 0.7f) / 0.3f else 0f
        } else {
            if (p > 0.9f) 1f else 0f
        }
        torch(level)
    }

    private fun torchCamera(cm: CameraManager): String? = torchId ?: cm.cameraIdList.firstOrNull {
        cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    }?.also { torchId = it }

    private fun isDimmable(): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        return try {
            val cm = getSystemService(CameraManager::class.java)
            val id = torchCamera(cm) ?: return false
            (cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1) > 1
        } catch (_: Exception) { false }
    }

    private fun torch(level: Float) {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = torchCamera(cm) ?: return
            if (level <= 0f) {
                if (torchOn) cm.setTorchMode(id, false)
                torchOn = false
                return
            }
            if (Build.VERSION.SDK_INT >= 33 && dimmable == true) {
                val max = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                cm.turnOnTorchWithStrengthLevel(id, (1 + (max - 1) * level).toInt().coerceIn(1, max))
            } else if (!torchOn) {
                cm.setTorchMode(id, true)
            }
            torchOn = true
        } catch (_: Exception) { }
    }

    @Composable
    private fun SunriseScreen() {
        val p = progress
        val night = Color(0xFF05030A)
        val ember = Color(0xFF4A0E0E)
        val orange = Color(0xFFFF7A1A)
        val gold = Color(0xFFFFE8A3)
        val top = when {
            p < 0.4f -> lerp(night, ember, p / 0.4f)
            p < 0.75f -> lerp(ember, orange, (p - 0.4f) / 0.35f)
            else -> lerp(orange, gold, (p - 0.75f) / 0.25f)
        }
        val bottom = lerp(night, orange, (p * 1.2f).coerceAtMost(1f))
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(top, bottom))).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.Bottom)
        ) {
            val textColor = if (p > 0.75f) Color(0xFF3A1A0A) else Color(0xCCFFFFFF)
            Text("🌅 Sunrise", color = textColor, fontSize = 22.sp)
            Text(
                "Alarm at " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(alarmAt)),
                color = textColor, fontSize = 16.sp
            )
            Text(
                if (dimmable == false) "Flashlight switches on in the final minute (this phone's flashlight can't dim)"
                else "Flashlight rises in the last 3 minutes",
                color = textColor, fontSize = 12.sp
            )
            TextButton(onClick = { close() }) { Text("I'm awake — close", color = textColor) }
        }
    }
}
