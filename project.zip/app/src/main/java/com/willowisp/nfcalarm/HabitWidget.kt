package com.willowisp.nfcalarm

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.widget.RemoteViews

/** Home-screen widget: 8-week wake-up grid, streak and latest badge. */
class HabitWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, build(c)) }
    }

    companion object {
        fun updateAll(c: Context) {
            val mgr = AppWidgetManager.getInstance(c)
            val ids = mgr.getAppWidgetIds(ComponentName(c, HabitWidget::class.java))
            ids.forEach { mgr.updateAppWidget(it, build(c)) }
        }

        private fun build(c: Context): RemoteViews {
            if (!Store.isPro(c)) return lockedView(c)
            Habit.applyFreezes(c)
            val rv = RemoteViews(c.packageName, R.layout.widget_habit)
            val badge = Habit.latestBadge(c)
            rv.setTextViewText(R.id.title, badge?.let { "${it.emoji} ${it.title}" } ?: "Will-O-Wisp")
            rv.setImageViewBitmap(R.id.grid, gridBitmap(c))
            rv.setTextViewText(R.id.footer, "🔥 ${Habit.streak(c)} streak · ${Habit.total(c)} total")
            val open = PendingIntent.getActivity(
                c, 3, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            return rv
        }

        /** Free users: a locked card that opens the Pro screen. */
        private fun lockedView(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget_habit)
            rv.setTextViewText(R.id.title, "✦ Habit widget is Pro")
            rv.setImageViewBitmap(R.id.grid, lockedBitmap())
            rv.setTextViewText(R.id.footer, "Tap to unlock")
            val open = PendingIntent.getActivity(
                c, 31, Intent(c, MainActivity::class.java).putExtra("openPro", true),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            return rv
        }

        private fun lockedBitmap(): Bitmap {
            val cell = 30f
            val gap = 7f
            val w = (8 * cell + 7 * gap).toInt()
            val h = (7 * cell + 6 * gap).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#22FFFFFF") }
            for (week in 0 until 8) for (day in 0 until 7) {
                val x = week * (cell + gap); val y = day * (cell + gap)
                canvas.drawRoundRect(RectF(x, y, x + cell, y + cell), 7f, 7f, dim)
            }
            val lock = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 90f; textAlign = Paint.Align.CENTER }
            canvas.drawText("🔒", w / 2f, h / 2f + 32f, lock)
            return bmp
        }

        private fun gridBitmap(c: Context): Bitmap {
            val cell = 30f
            val gap = 7f
            val w = (8 * cell + 7 * gap).toInt()
            val h = (7 * cell + 6 * gap).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val done = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8B7CFF") }
            val missed = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#33FFFFFF") }
            val frozen = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#9FD8F5") }
            Habit.grid(c).forEachIndexed { week, days ->
                days.forEachIndexed { day, v ->
                    if (v >= 0) {
                        val x = week * (cell + gap)
                        val y = day * (cell + gap)
                        canvas.drawRoundRect(RectF(x, y, x + cell, y + cell), 7f, 7f, when (v) { 1 -> done; 2 -> frozen; else -> missed })
                    }
                }
            }
            return bmp
        }
    }
}
