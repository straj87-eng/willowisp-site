package com.willowisp.nfcalarm

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** Saves the details of any crash so the next launch can offer to email them to support. */
class WispApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                File(filesDir, CRASH_FILE).writeText(
                    "Thread: ${thread.name}\nVersion: ${BuildConfig.VERSION_NAME}\n" +
                        "Phone: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}, Android ${android.os.Build.VERSION.RELEASE}\n\n" +
                        sw.toString().take(6000)
                )
            } catch (_: Exception) { }
            previous?.uncaughtException(thread, error)
        }
    }

    companion object { const val CRASH_FILE = "last_crash.txt" }
}
