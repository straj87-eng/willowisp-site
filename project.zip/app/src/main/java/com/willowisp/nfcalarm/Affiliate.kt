package com.willowisp.nfcalarm

import android.content.Context

/**
 * Amazon affiliate link to recommended NFC stickers, matched to the user's country.
 * Replace each YOUR_TAG_… with your Amazon Associates tracking ID for that marketplace
 * (each Amazon store has its own Associates programme and its own tag).
 */
object Affiliate {
    private data class Market(val domain: String, val tag: String)

    private const val QUERY = "NTAG213+NFC+stickers"

    private val MARKETS = mapOf(
        "IN" to Market("www.amazon.in", "YOUR_TAG_IN-21"),
        "US" to Market("www.amazon.com", "YOUR_TAG_US-20"),
        "CA" to Market("www.amazon.ca", "YOUR_TAG_CA-20"),
        "GB" to Market("www.amazon.co.uk", "YOUR_TAG_UK-21"),
        "DE" to Market("www.amazon.de", "YOUR_TAG_DE-21"),
        "AT" to Market("www.amazon.de", "YOUR_TAG_DE-21"),
        "FR" to Market("www.amazon.fr", "YOUR_TAG_FR-21"),
        "IT" to Market("www.amazon.it", "YOUR_TAG_IT-21"),
        "ES" to Market("www.amazon.es", "YOUR_TAG_ES-21"),
        "NL" to Market("www.amazon.nl", "YOUR_TAG_NL-21"),
        "AE" to Market("www.amazon.ae", "YOUR_TAG_AE-21"),
        "SA" to Market("www.amazon.sa", "YOUR_TAG_SA-21"),
        "AU" to Market("www.amazon.com.au", "YOUR_TAG_AU-22"),
        "JP" to Market("www.amazon.co.jp", "YOUR_TAG_JP-22"),
        "SG" to Market("www.amazon.sg", "YOUR_TAG_SG-22")
    )

    /** Link for the user's region; falls back to Amazon.com. Untagged until you add your IDs. */
    fun url(c: Context): String {
        val m = MARKETS[Subscribe.country(c)] ?: MARKETS.getValue("US")
        val tag = if (m.tag.startsWith("YOUR_TAG")) "" else "&tag=${m.tag}"
        return "https://${m.domain}/s?k=$QUERY$tag"
    }

    fun storeName(c: Context): String = (MARKETS[Subscribe.country(c)] ?: MARKETS.getValue("US")).domain.removePrefix("www.")
}
