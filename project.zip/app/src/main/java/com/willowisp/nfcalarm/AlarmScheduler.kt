package com.willowisp.nfcalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmScheduler {

    fun nextTrigger(a: AlarmItem, now: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, a.hour)
            set(Calendar.MINUTE, a.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        for (i in 0..7) {
            if (i > 0) cal.add(Calendar.DAY_OF_YEAR, 1)
            if (cal.timeInMillis > now && (a.days.isEmpty() || cal.get(Calendar.DAY_OF_WEEK) in a.days)) {
                return cal.timeInMillis
            }
        }
        return cal.timeInMillis
    }

    private fun operation(c: Context, id: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .setAction("com.willowisp.nfcalarm.FIRE")
            .putExtra("id", id)
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(c: Context, a: AlarmItem) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(operation(c, a.id))
        Sunrise.cancel(c, a.id)
        if (!a.enabled) return
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return
        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(nextTrigger(a), show), operation(c, a.id))
        Sunrise.schedule(c, a)
    }

    fun cancel(c: Context, id: Int) {
        c.getSystemService(AlarmManager::class.java).cancel(operation(c, id))
        Sunrise.cancel(c, id)
    }

    fun rescheduleAll(c: Context) = Store.alarms(c).forEach { schedule(c, it) }

    fun nextEnabled(c: Context): Long? =
        Store.alarms(c).filter { it.enabled }.minOfOrNull { nextTrigger(it) }

    fun untilText(trigger: Long): String {
        val mins = ((trigger - System.currentTimeMillis() + 59_999) / 60_000).coerceAtLeast(0)
        val d = mins / 1440
        val h = (mins % 1440) / 60
        val m = mins % 60
        return buildString {
            append("⏰ Alarm in ")
            if (d > 0) append("$d d ")
            if (h > 0 || d > 0) append("$h h ")
            append("$m min")
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val a = Store.alarms(c).firstOrNull { it.id == id } ?: return
        // By design the alarm switches itself off after it rings: the user re-arms it every night.
        Store.upsertAlarm(c, a.copy(enabled = false))
        c.startForegroundService(Intent(c, AlarmService::class.java).putExtra("id", id))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val since = Store.ringingSince(c)
            // alarm was still ringing when the phone went off (within the last 3 hours) = switched off to escape
            if (since > 0 && System.currentTimeMillis() - since < 3 * 60 * 60 * 1000L) {
                Habit.applyEscapePenalty(c, since)
            }
            Store.setRingingSince(c, 0L)   // never resume the alarm
        }
        AlarmScheduler.rescheduleAll(c)
        Bedtime.schedule(c)
    }
}
