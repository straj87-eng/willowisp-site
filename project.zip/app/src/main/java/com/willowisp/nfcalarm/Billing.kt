package com.willowisp.nfcalarm

import android.app.Activity
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams

/**
 * One Google Play subscription (create it in Play Console with exactly these IDs):
 *   pro_yearly : base plan "yearly" (₹299 India / US$6.99 elsewhere)
 *                offer "trial" = 7-day free trial (eligibility: new customer acquisition)
 */
class Billing(
    private val activity: Activity,
    private val onLoaded: () -> Unit,
    private val onPro: () -> Unit,
    private val onProLost: () -> Unit
) : PurchasesUpdatedListener {

    companion object {
        const val YEARLY = "pro_yearly"
    }

    data class Prices(val yearly: String?, val trialDays: Int)

    private var sub: ProductDetails? = null
    var loaded = false
        private set

    private val client: BillingClient = BillingClient.newBuilder(activity)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection()   // Billing 8: reconnects automatically if Play's service drops
        .build()

    fun start() {
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    loadProduct()
                    restore()
                }
            }
            override fun onBillingServiceDisconnected() { }
        })
    }

    private fun loadProduct() {
        val params = QueryProductDetailsParams.newBuilder().setProductList(
            listOf(
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(YEARLY).setProductType(BillingClient.ProductType.SUBS).build()
            )
        ).build()
        client.queryProductDetailsAsync(params) { _, result ->
            sub = result.productDetailsList.firstOrNull()
            loaded = sub != null
            activity.runOnUiThread { onLoaded() }
        }
    }

    /** The trial offer when the user is eligible, otherwise the base plan. */
    private fun bestOffer(): ProductDetails.SubscriptionOfferDetails? {
        val offers = sub?.subscriptionOfferDetails ?: return null
        return offers.firstOrNull { it.offerId == "trial" }
            ?: offers.firstOrNull { it.offerId == null }
            ?: offers.firstOrNull()
    }

    private fun trialDays(o: ProductDetails.SubscriptionOfferDetails?): Int {
        val free = o?.pricingPhases?.pricingPhaseList?.firstOrNull { it.priceAmountMicros == 0L } ?: return 0
        val period = free.billingPeriod      // ISO-8601, e.g. "P7D" or "P1W"
        val n = period.filter { it.isDigit() }.toIntOrNull() ?: return 0
        return when {
            period.endsWith("D") -> n
            period.endsWith("W") -> n * 7
            period.endsWith("M") -> n * 30
            else -> 0
        }
    }

    fun prices(): Prices {
        val o = bestOffer()
        val price = o?.pricingPhases?.pricingPhaseList?.lastOrNull { it.priceAmountMicros > 0 }?.formattedPrice
        return Prices(price, trialDays(o))
    }

    /** Returns false if the product isn't available (e.g. sideloaded build). */
    fun buy(): Boolean {
        val d = sub ?: return false
        val o = bestOffer() ?: return false
        val params = BillingFlowParams.newBuilder().setProductDetailsParamsList(
            listOf(
                BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(d).setOfferToken(o.offerToken).build()
            )
        ).build()
        client.launchBillingFlow(activity, params)
        return true
    }

    /** Re-checks Play for an active subscription (also used by "Restore purchases"). */
    fun restore() {
        client.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        ) { result, purchases ->
            var found = false
            purchases.forEach { if (handle(it)) found = true }
            val ok = result.responseCode == BillingClient.BillingResponseCode.OK
            activity.runOnUiThread {
                when {
                    found -> onPro()
                    ok -> onProLost()
                    else -> { }
                }
            }
        }
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        var granted = false
        purchases?.forEach { if (handle(it)) granted = true }
        if (granted) {
            Analytics.log(activity, "pro_purchase", "plan" to "yearly")   // a new purchase (restores don't pass here)
            activity.runOnUiThread { onPro() }
        }
    }

    private fun handle(p: Purchase): Boolean {
        if (p.purchaseState != Purchase.PurchaseState.PURCHASED) return false
        if (p.products.none { it.startsWith("pro_") }) return false
        if (!p.isAcknowledged) {
            client.acknowledgePurchase(
                AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()
            ) { }
        }
        return true
    }
}
